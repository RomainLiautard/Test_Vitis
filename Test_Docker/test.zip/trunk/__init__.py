# coding: utf-8

import os
import argparse
import platform
from Launcher import Launcher
from Translation import Translation

if __name__ == '__main__':
    tradClass = Translation()
    trad = tradClass.french()

    # Expected arguments
    parser = argparse.ArgumentParser(description=trad["init_1"])
    parser.add_argument('-a', '--action', dest='action', action='store', choices=['install', 'update', 'uninstall'], required=True)
    parser.add_argument('-n', '--nature', dest='serviceNat', action='store', choices=['app', 'client', 'vas', 'ws', 'schema'], required=True)
    parser.add_argument('-s', '--service', dest='serviceName', action='store')
    parser.add_argument('-dir', '--directory', dest='directory', action='store')
    parser.add_argument('-appdir', '--applicationdirectory', dest='appDirectory', action='store')
    parser.add_argument('-vasdir', '--vasdirectory', dest='vasDirectory', action='store')
    parser.add_argument('-db', '--database', dest='databaseInfos', action='store')
    parser.add_argument('-dblogin', '--databaselogin', dest='dbUsername', action='store')
    parser.add_argument('-dbpswd', '--databasepassword', dest='dbPassword', action='store')
    parser.add_argument('-as', '--apacheservice', dest='apacheService', action='store')
    parser.add_argument('-asport', '--apacheserviceport', dest='apacheServicePort', action='store')
    parser.add_argument('-vasurl', dest='vasUrl', action='store')
    parser.add_argument('-appadmin', '--applicationadministrator', dest='adminLogin', action='store')
    parser.add_argument('-appadminpswd', '--applicationadminpassword', dest='adminPswd', action='store')
    parser.add_argument('-env', '--environment', dest='environment', action='store')
    parser.add_argument('-sql', dest='sqlReplace', action='store')
    parser.add_argument('-v', '--verbose', dest='verbose', action='store', default='False')
    parser.add_argument('-log', dest='logPath', action='store')
    parsed_args = parser.parse_args()

# Custom check of arguments
    sError = ''
    if parsed_args.action != 'uninstall':
        if (parsed_args.serviceNat == 'ws' or parsed_args.serviceNat == 'schema') and parsed_args.serviceName is None:
            sError += ' -s/--service,'
        if parsed_args.dbUsername is None:
            sError += ' -dblogin/--databaselogin,'
        if parsed_args.dbPassword is None:
            sError += ' -dbpswd/--databasepassword,'

        if parsed_args.serviceNat == 'vas' or (parsed_args.serviceNat == 'schema' and parsed_args.serviceName == 's_vitis'):
            if parsed_args.adminLogin is None:
                sError += ' -appadmin/--applicationadministrator,'

    if (parsed_args.serviceNat != 'ws' and parsed_args.serviceNat != 'schema') and parsed_args.apacheService is None:
        sError += ' -as/--apacheservice,'

    if parsed_args.directory is None:
        if parsed_args.serviceNat in ('client', 'app'):
            if parsed_args.appDirectory is None:
                sError += ' -appdir/--applicationdirectory,'
        if parsed_args.serviceNat not in ('client', 'schema'):
            if parsed_args.vasDirectory is None:
                sError += ' -vasdir/--vasdirectory,'

    if sError != '':
        parser.error(trad["init_2"].format(parsed_args.serviceNat, sError[1:-1]))

    if parsed_args.serviceNat == 'ws':
        parsed_args.serviceNat = 'web_services'

    if parsed_args.serviceNat != 'schema':
        if parsed_args.appDirectory is None:
            parsed_args.appDirectory = os.path.join(parsed_args.directory, 'client')
        parsed_args.appDirectory = os.path.abspath(parsed_args.appDirectory)
        if parsed_args.vasDirectory is None:
            parsed_args.vasDirectory = os.path.join(parsed_args.directory, 'vas')
        parsed_args.vasDirectory = os.path.abspath(parsed_args.vasDirectory)

        del parsed_args.directory

        if parsed_args.apacheServicePort is None:
            parsed_args.apacheServicePort = '443'

        if parsed_args.vasUrl is None:
            parsed_args.vasUrl = 'https://' + platform.uname().node + ':' + parsed_args.apacheServicePort
            parsed_args.checkUrl = 'https://127.0.0.1:' + parsed_args.apacheServicePort
        else:
            parsed_args.checkUrl = parsed_args.vasUrl

    parsed_args.installDep = True
    if parsed_args.serviceNat == 'client':
        parsed_args.serviceNat = 'app'
        parsed_args.installDep = False

    # split database information
    if parsed_args.databaseInfos is not None:
        aDatabaseInfos = parsed_args.databaseInfos.split(",")
        parsed_args.dbHost = aDatabaseInfos[0]
        parsed_args.dbPort = aDatabaseInfos[1]
        parsed_args.dbName = aDatabaseInfos[2]
    else:
        parsed_args.dbHost = None
        parsed_args.dbPort = None
        parsed_args.dbName = None

    del parsed_args.databaseInfos

    parsed_args.environmentAlias = ""
    if parsed_args.environment is not None and parsed_args.environment != "":
        parsed_args.environmentAlias = "_" + parsed_args.environment
        del parsed_args.environment

    if parsed_args.verbose == 'true':
        parsed_args.verbose = True

    if parsed_args.verbose == 'False':
        parsed_args.verbose = False

    args = vars(parsed_args)

    if args['sqlReplace'] is not None:
        aTmp = args['sqlReplace'].split("|")
        args['sqlReplace'] = {}
        for sTmp in aTmp:
            tmp = sTmp.split('=')
            args['sqlReplace'][tmp[0]] = tmp[1]

    # Process launching
    Launcher(args, trad)
