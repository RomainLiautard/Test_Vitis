# coding: utf-8
import os
import inspect
import xmldict


class Schema(object):
	"""
	Class Schema:
	"""
	def __init__(self, Tools, name, version, ws, dependsOn):
		self.name = name
		self.version = version
		self.Tools = Tools
		self.dependsOn = dependsOn
		self.ws = ws
		self.sqlQueriesFile = os.path.join(self.Tools.params['ressourcesPath'], "vas", "complement", ws, "sqlQueries.xml")

	def Install(self):
		# checking database existence, configure it if exist, else create one
		self.Tools.logger.debug(self.Tools.trad["Schema_1"].format(self.Tools.postgres['dbName']))
		result = self.Tools.DatabaseExist()
		if result[0] == 0:
			databaseExist = result[1]
		else:
			return result
		if databaseExist:
			result = self.Tools.GetVersionSchema(self.name)
			if result[0] == 0:
				version = result[1]
			else:
				return result
		else:
			version = ''

		if version != 'trunk':
			if version == '':
				if self.ws == 'vas':
					result = self.VasInstall(databaseExist)
					if result[0] != 0:
						return result
				else:
					if databaseExist:
						self.Tools.logger.info(self.Tools.trad["Schema_2"])
						self.Tools.logger.debug(self.Tools.trad["Schema_3"].format(self.sqlQueriesFile, self.Tools.postgres['dbName']))
						result = self.SendXmlToDataBase()
						if result[0] != 0:
							return result
					else:
						return [1, self.Tools.trad["Schema_4"], inspect.stack()[0]]
			else:
				versionSchema = int(version.replace('.', ''))
				versionInstaller = int(self.version.replace('.', ''))
				if versionSchema == versionInstaller:
					return[1, self.Tools.trad["Schema_5"], inspect.stack()[0]]
				elif versionSchema < versionInstaller:
					return[1, self.Tools.trad["Schema_6"].format(version), inspect.stack()[0]]
				else:
					return[1, self.Tools.trad["Schema_7"].format(version), inspect.stack()[0]]
		else:
			return[1, self.Tools.trad["Schema_8"], inspect.stack()[0]]
		return [0, ""]

	def Update(self):
		self.Tools.logger.info(self.Tools.trad["Schema_9"].format(self.name, self.Tools.postgres['dbName']))
		#Peut être qu'il faudrait passer en argument la current_version car déjà vérifier
		result = self.Tools.GetVersionSchema(self.name)
		if result[0] == 0:
			currentVersion = result[1]
		else:
			return result

		if currentVersion == "trunk" and self.version != "trunk":
			return [1, self.Tools.trad["Schema_10"], inspect.stack()[0]]
		if currentVersion != "" and currentVersion != "trunk" and self.version == "trunk":
			return [1, self.Tools.trad["Schema_11"], inspect.stack()[0]]

		result = self.SendXmlToDataBase(currentVersion)
		if result[0] != 0:
			return result
		return [0, ""]

	def DisplayInfos(self):
		self.Tools.logger.debug(self.Tools.trad["Schema_12"].format(self.name))
		self.Tools.logger.debug(self.Tools.trad["Schema_13"].format(self.version))
		if self.Tools.postgres['dbName'] is not None:
			self.Tools.logger.debug(self.Tools.trad["Schema_14"].format(self.Tools.postgres['dbName']))
			self.Tools.logger.debug(self.Tools.trad["Schema_15"].format(self.Tools.postgres['dbUsername']))
			if self.Tools.postgres['dbPassword'] is not None:
				self.Tools.logger.debug(self.Tools.trad["Schema_16"].format(self.Tools.postgres['dbPassword']))
			self.Tools.logger.debug(self.Tools.trad["Schema_17"].format(self.Tools.postgres['dbHost']))
			self.Tools.logger.debug(self.Tools.trad["Schema_18"].format(self.Tools.postgres['dbPort']))
		for dependence in self.dependsOn:
			result = dependence.DisplayInfos()
			if result[0] != 0:
				return result
		return [0, ""]


# Special vas installation process
	def VasInstall(self, databaseExist):
		if databaseExist:
			encoding = ""
			result = self.Tools.GetQuery("SELECT pg_encoding_to_char(encoding) FROM pg_database WHERE datname = '" + self.Tools.postgres['dbName'] + "'", "postgres")
			if result[0] == 0:
				encoding = result[1]
			else:
				return result

			self.Tools.logger.debug(self.Tools.trad["Schema_23"].format(encoding))
			if encoding != "UTF8":
				return [1, self.Tools.trad["Schema_24"].format(self.Tools.postgres['dbName']), inspect.stack()[0]]
		else:
			self.Tools.logger.info(self.Tools.trad["Schema_25"])
			# creation of the new database
			# "create database" works only if autocommit is set to True
			self.Tools.logger.debug(self.Tools.trad["Schema_26"].format(self.Tools.postgres['dbName']))
			result = self.Tools.ExecuteSql("CREATE DATABASE \"" + self.Tools.postgres['dbName'] + "\" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE='C' CONNECTION LIMIT=-1 OWNER = u_vitis", "postgres", True)
			if result[0] != 0:
				return result

		# setting up database
		# Send sqlQueries to database
		self.Tools.logger.info(self.Tools.trad["Schema_27"])
		self.Tools.logger.debug(self.Tools.trad["Schema_28"].format(self.sqlQueriesFile, self.Tools.postgres['dbName']))
		result = self.SendXmlToDataBase()
		if result[0] != 0:
			return result
		return [0, ""]

	def SendXmlToDataBase(self, fromVersion=None):
		file = open(self.sqlQueriesFile, 'r', encoding="utf-8")
		result = file.readlines()
		try:
			queriesCollection = xmldict.xml_to_dict(''.join(result))['sqlQueries']['queriesCollection']
		except BaseException as err:
			self.Tools.logger.error(self.Tools.trad["Schema_29"].format(self.sqlQueriesFile, str(err)))
			return [1, str(err), inspect.stack()[0]]

		if type(queriesCollection['query']).__name__ != 'list':
			tmp = queriesCollection['query']
			queriesCollection['query'] = []
			queriesCollection['query'].append(tmp)

		requestList = []
		for query in queriesCollection['query']:
			queryVersion = query["version"]
			if fromVersion is not None:
				if int(queryVersion.replace('.', '')) <= int(fromVersion.replace('.', '')):
					continue

			query["code"] = self.ReplaceSql(query["code"])
			queryLines = query["code"].split("\n")
			for queryLine in queryLines:
				queryLine = queryLine.strip("\t ").strip().rstrip('\n\r')
				if (queryLine != '') and (not queryLine.startswith('--')):
					requestList.append(queryLine)

		self.Tools.logger.debug(self.Tools.trad["Schema_30"])
		pathVersion = os.path.join(self.Tools.params['ressourcesPath'], 'vas', 'complement', self.ws, "version.inc")

		versionFile = open(pathVersion, 'r', encoding="utf-8")
		versionFileData = versionFile.readlines()
		versionFile.close()
		currentVersion = currentBuild = currentDate = None
		for line in versionFileData:
			if "VM_VERSION" in line:
				currentVersion = line.split('"')[-2]
				self.Tools.logger.debug(self.Tools.trad["Schema_31"].format(currentVersion))
			if "VM_BUILD" in line:
				currentBuild = line.split('"')[-2]
				self.Tools.logger.debug(self.Tools.trad["Schema_32"].format(currentBuild))
			if "VM_MONTH_YEAR" in line:
				currentDate = line.split('"')[-2]
				self.Tools.logger.debug(self.Tools.trad["Schema_33"].format(currentDate))

		if currentVersion is None or currentBuild is None or currentDate is None:
			return [1, self.Tools.trad["Schema_34"], inspect.stack()[0]]

		requestList.append("UPDATE " + self.name + ".version SET active=False")
		requestList.append("INSERT INTO " + self.name + ".version (version, build, date, active) VALUES ('" + currentVersion + "', '" + currentBuild + "', to_date('" + currentDate + "', 'MM_YYYY'), true)")

		result = self.Tools.ExecuteSql(requestList)
		if result[0] != 0:
			return result

		return [0, ""]

	def ReplaceSql(self, code):
		if self.Tools.params['sqlReplace'] is not None:
			for key, value in self.Tools.params['sqlReplace'].items():
				code = code.replace('$(' + key + ')', value)
		return code

	def Remove(self):
		depenceList = self.dependsOn
		for dependence in depenceList:
			if dependence.nature.startswith('extern'):
				result = dependence.CheckExtern(self.Tools.info['action'])
				if result[0] != 0:
					return result
		return[0, ""]
