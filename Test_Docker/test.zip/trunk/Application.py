# coding: utf-8
import os
import inspect
import json


class Application(object):
	""" Class Application description:	"""
	def __init__(self, Tools, name, version, dependsOn):
		self.name = name
		self.version = version
		self.dependsOn = dependsOn
		self.Tools = Tools

	def Install(self):
		# checking if not already installed
		if os.path.isdir(os.path.join(self.Tools.params['appDirectory'])):
			return [1, self.Tools.trad["Application_1"].format(os.path.join(self.Tools.params['appDirectory'])), inspect.stack()[0]]

		# checking aliases
		result = self.Tools.DoesAliasExist(os.path.join(self.Tools.params['ressourcesPath'], "app", "complement", "apache.conf"))
		if result[0] == 0:
			doesAliasExist = result[1]
		else:
			return result
		if doesAliasExist:
			return [1, self.Tools.trad["Application_2"], inspect.stack()[0]]

		self.Tools.logger.info(self.Tools.trad["Application_3"].format(self.name))
		# copy ress/"name"  ---->  appDirectory/
		result = self.Tools.fileManipulator.RecursiveOverwriteCopy(os.path.join(self.Tools.params['ressourcesPath'], "app", self.name), self.Tools.params['appDirectory'])
		if result[0] != 0:
			return result
		result = self.ConfigUp('install')
		if result[0] != 0:
			return result
		result = self.ExecuteSql()
		if result[0] != 0:
			return result
		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['appDirectory'], "conf", "properties.json"), "unstable", "stable")
		if result[0] != 0:
			return result

		return [0, ""]

	def ConfigUp(self, mode):
		# properties.json configuration
		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['appDirectory'], "conf", "properties.json"), "[PORT]", self.Tools.apache['port'])
		if result[0] != 0:
			return result
		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['appDirectory'], "conf", "properties.json"), "rest[ENV]", "rest" + self.Tools.apache['environmentAlias'])
		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['appDirectory'], "conf", "properties.json"), "proxy[ENV]", "proxy" + self.Tools.apache['environmentAlias'])
		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['appDirectory'], "conf", "properties.json"), "[ENV]", self.Tools.apache['environmentAlias'].lstrip('_'))
		if result[0] != 0:
			return result

		# creating aliases and appending them to httpd.conf
		if mode == 'update':
			result = self.Tools.fileManipulator.RemoveAlias('app')
			if result[0] != 0:
				return result

		result = self.Tools.fileManipulator.AddAlias('app')
		if result[0] != 0:
			return result

		self.Tools.logger.debug(self.Tools.trad["Application_4"])
		result = self.Tools.CheckApacheModule('app')
		if result[0] != 0:
			return result

		return [0, ""]

	def ExecuteSql(self):
		# checking ws status
		propertiesFile = open(os.path.join(self.Tools.params['appDirectory'], "conf", "properties.json"), 'r', encoding="utf-8")
		propertiesFileStr = propertiesFile.read()
		propertiesFile.close()
		propertiesFileData = json.loads(propertiesFileStr)

		if "application" in propertiesFileData:
			appName = propertiesFileData['application']
		else:
			appName = self.name

		# creating vitis admin login
		if self.Tools.params['adminLogin'] is None:
			return [1, self.Tools.trad["Application_5"], inspect.stack()[0]]
		self.Tools.logger.debug(self.Tools.trad["Application_6"].format(self.Tools.params['adminLogin']))
		result = self.Tools.CheckUser(self.Tools.params['adminLogin'])
		if result[0] == 0:
			bUserExist = result[1]
		else:
			return result

		requestList = []
		if not bUserExist:
			self.Tools.logger.debug(self.Tools.trad["Application_7"].format(self.Tools.params['adminLogin']))
			if self.Tools.params['adminPswd'] is None:
				return [1, self.Tools.trad["Application_8"], inspect.stack()[0]]
			# create role adminLogin
			self.Tools.logger.info(self.Tools.trad["Application_9"].format(self.Tools.params['adminLogin']))
			requestList.append("CREATE ROLE \"" + self.Tools.params['adminLogin'] + "\" LOGIN ENCRYPTED PASSWORD \'" + self.Tools.params['adminPswd'] + "\' NOSUPERUSER INHERIT NOCREATEDB CREATEROLE NOREPLICATION")
		else:
			# modify role adminLogin
			self.Tools.logger.info(self.Tools.trad["Application_10"].format(self.Tools.params['adminLogin']))
			requestList.append("ALTER ROLE \"" + self.Tools.params['adminLogin'] + "\" CREATEROLE")

		# Give right to adminLogin
		self.Tools.logger.debug(self.Tools.trad["Application_11"].format(self.Tools.params['adminLogin']))
		requestList.append("GRANT vitis_admin TO \"" + self.Tools.params['adminLogin'] + "\"")
		requestList.append("GRANT vitis_user TO \"" + self.Tools.params['adminLogin'] + "\"")
		requestList.append("INSERT INTO s_vitis.\"user\" (user_id, login, name, restriction) SELECT nextval('s_vitis.seq_common'::regclass), '" + self.Tools.params['adminLogin'] + "', '" + self.Tools.params['adminLogin'] + "', '%' WHERE NOT EXISTS (SELECT 1 FROM s_vitis.\"user\" WHERE login = '" + self.Tools.params['adminLogin'] + "')")

		# Insert Application name
		self.Tools.logger.debug(self.Tools.trad["Application_12"].format(self.Tools.params['adminLogin']))
		requestList.append("INSERT INTO s_vitis.vm_application (name) SELECT '" + appName + "' WHERE NOT EXISTS (SELECT 1 FROM s_vitis.vm_application WHERE name = '" + appName + "')")

		for module in os.listdir(os.path.join(self.Tools.params['appDirectory'], "modules")):
			requestList.append("INSERT INTO s_vitis.vm_application_module (application_name, module_name) SELECT '" + appName + "', '" + module + "' WHERE NOT EXISTS (SELECT 1 FROM s_vitis.vm_application_module WHERE application_name = '" + appName + "' AND module_name = '" + module + "')")

		result = self.Tools.ExecuteSql(requestList)
		if result[0] != 0:
			return result

		return [0, ""]

	def DisplayInfos(self):
		self.Tools.logger.debug(self.Tools.trad["Application_13"].format(self.name))
		self.Tools.logger.debug(self.Tools.trad["Application_14"].format(self.version))
		if self.Tools.params['appDirectory'] is not None:
			self.Tools.logger.debug(self.Tools.trad["Application_15"].format(self.Tools.params['appDirectory']))
		if not self.Tools.apache['vasUrl'] is None:
			self.Tools.logger.debug(self.Tools.trad["Application_16"].format(self.Tools.apache['vasUrl'] + "/rest" + self.Tools.apache['environmentAlias']))
		if not self.Tools.apache['name'] is None:
			self.Tools.logger.debug(self.Tools.trad["Application_17"].format(self.Tools.apache['name']))
		self.Tools.logger.debug(self.Tools.trad["Application_18"])
		for dependence in self.dependsOn:
			result = dependence.DisplayInfos()
			if result[0] != 0:
				return result
		return [0, ""]

	def Update(self):
		# checking if installed
		if not os.path.isdir(os.path.join(self.Tools.params['appDirectory'])):
			return [1, self.trad["Application_31"].format(self.Tools.params['appDirectory'], self.name), inspect.stack()[0]]
		# checking app status

		propertiesFile = open(os.path.join(self.Tools.params['appDirectory'], "conf", "properties.json"), 'r', encoding="utf-8")
		propertiesFileStr = propertiesFile.read()
		propertiesFile.close()
		propertiesFileData = json.loads(propertiesFileStr)

		status = propertiesFileData['status']
		self.Tools.logger.debug("current ws status: " + status)

		if status is None:
			return [1, self.Tools.trad["Application_19"], inspect.stack()[0]]
		if status != "stable":
			return [1, self.Tools.trad["Application_20"], inspect.stack()[0]]

		self.Tools.logger.info("versions comparison")

		currentVersion = propertiesFileData['version']
		if currentVersion is None:
			return [1, self.Tools.trad["Application_21"], inspect.stack()[0]]

		if currentVersion == "trunk" and self.version != "trunk":
			return [1, self.Tools.trad["Application_22"], inspect.stack()[0]]
		if currentVersion != "" and currentVersion != "trunk" and self.version == "trunk":
			return [1, self.Tools.trad["Application_23"], inspect.stack()[0]]

		try:
			# overwriting with last version of ws
			self.Tools.logger.info(self.Tools.trad["Application_28"])
			result = self.Tools.fileManipulator.ReplaceDirectory(os.path.join(self.Tools.params['ressourcesPath'], "app", self.name), self.Tools.params['appDirectory'])
			if result[0] != 0:
				return result

		except BaseException as err:
			return [1, err, inspect.stack()[0]]

		result = self.ConfigUp('update')
		if result[0] != 0:
			return result

		# get appname
		propertiesFile = open(os.path.join(self.Tools.params['appDirectory'], "conf", "properties.json"), 'r', encoding="utf-8")
		propertiesFileStr = propertiesFile.read()
		propertiesFile.close()
		propertiesFileData = json.loads(propertiesFileStr)
		if 'application' in propertiesFileData:
			appName = propertiesFileData['application']
		else:
			appName = self.name

		requestList = []
		for module in os.listdir(os.path.join(self.Tools.params['appDirectory'], "modules")):
			requestList.append("INSERT INTO s_vitis.vm_application_module (application_name, module_name) SELECT '" + appName + "', '" + module + "' WHERE NOT EXISTS (SELECT 1 FROM s_vitis.vm_application_module WHERE application_name = '" + appName + "' AND module_name = '" + module + "')")
		result = self.Tools.ExecuteSql(requestList)
		if result[0] != 0:
			return result

		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['appDirectory'], "conf", "properties.json"), "unstable", "stable")
		if result[0] != 0:
			return result
		return [0, ""]

	def Remove(self):
		self.Tools.logger.info(self.Tools.trad["Application_30"].format(self.name + self.Tools.apache['environmentAlias']))
		result = self.Tools.fileManipulator.RemoveAlias('app')
		if result[0] != 0:
			return result
		result = self.Tools.fileManipulator.RecursiveDelete(self.Tools.params['appDirectory'])
		if result[0] != 0:
			return result
		return [0, ""]
