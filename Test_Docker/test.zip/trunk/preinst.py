# coding: utf-8
# pylint: disable=E1101
# ----------------------------------------------------------------------
# Author :  Veremes - Sébastien Legrand
# Date :    2016-02-26
# Goal :    Extract from SVN files updated since the number's build
# install pysvn #http://pysvn.tigris.org/project_downloads.html
# pip install xmldict => modifiez xmldict.py, changez iteritems par items pour une compatibilité python 3
# ----------------------------------------------------------------------

import os
import shutil
import datetime
import argparse
import sys
import zipfile
import re
import ctypes
import requests
import pysvn
import xmldict

# --- Global
sSvnServerUrl = "svn://vm02.veremes.net/produit_vitis"
sSvnServerLocal = ""
sRessourcesPathOnline = "http://freedownload.veremes.net/products/ressources"
sRessourcesPathLocal = r"\\192.168.1.37\Ressources\vai"

sWorkDir = os.path.dirname(os.path.abspath(__file__))
sPublishDir = sWorkDir + "/ressources"
sApplicationVersion = ""
sApplicationName = ""
bOnlineRessources = True
bOnlineSVN = True
ressourceDict = {}
sourceDict = []
lDepExtern = {}
clientSvn = pysvn.Client()
lHiddenImports = []
highestBuild = 0


def start():
    if ctypes.windll.shell32.IsUserAnAdmin() == 0:
        print("not launched as administrator, please open your command-line with administrator privileges")
        exit()
    # Expected arguments
    parser = argparse.ArgumentParser(description='description du programme')
    parser.add_argument('-app', dest='appName', action='store', required=True)
    parser.add_argument('-stable', dest='versionStable', action='store', default=True)
    parser.add_argument('-os', dest='os', action='store', choices=['windows', 'linux', 'both'], default='windows')
    parser.add_argument('-pack', dest='pack', action='store', choices=['normal', 'debug', 'both'], default='normal')
    parser.add_argument('-pyinstallerDir', dest='pyinstallerDir', action='store')
    parser.add_argument('-sExportUser', dest='sExportUser', action='store')
    parser.add_argument('-sExportPass', dest='sExportPass', action='store')
    parser.add_argument('-clean', dest='clean', action='store', choices=['True', 'False'], default='True')
    parser.add_argument('-outputDir', dest='outputDir', action='store')
    parser.add_argument('-onlineRessources', dest='onlineRessources', action='store', choices=['True', 'False'], default='True')
    parser.add_argument('-onlineSVN', dest='onlineSVN', action='store', choices=['True', 'False'], default='True')
    parser.add_argument('-localSVNPath', dest='localSVNPath', action='store')
    parsed_args = parser.parse_args()

    global sApplicationName
    global sApplicationVersion
    global sSvnServerLocal
    global bOnlineRessources
    global bOnlineSVN

    #if not parsed_args.onlineSVN:
    #	if parsed_args.appDirectory is None:
    #		sError += ' -appdir/--applicationdirectory,'
    #	if parsed_args.serviceNat not in ('client', 'schema'):
    #		if parsed_args.vasDirectory is None:
    #			sError += ' -vasdir/--vasdirectory,'
    #
    #if sError != '':
    #	parser.error(trad["init_2"].format(parsed_args.serviceNat, sError[1:-1]))

    if parsed_args.onlineRessources == "True":
        bOnlineRessources = True
    else:
        bOnlineRessources = False

    if parsed_args.onlineSVN == "True":
        bOnlineSVN = True
    else:
        # Check if params svn path exists
        if parsed_args.localSVNPath is None:
            parser.error("Le paramètre localSVNPath doit être renseigné quand le paramètre onlineSVN est à False")
        else:
            if not os.path.isdir(parsed_args.localSVNPath):
                parser.error("Le chemin " + parsed_args.localSVNPath + " n'est pas valide")
            else:
                sSvnServerLocal = parsed_args.localSVNPath
                clientSvn.update(sSvnServerLocal)
        bOnlineSVN = False

    if parsed_args.outputDir is not None:
        sOutputDir = parsed_args.outputDir
    else:
        sOutputDir = ''

    if parsed_args.pyinstallerDir is not None:
        sPyinstallerDir = parsed_args.pyinstallerDir + '/'
    else:
        sPyinstallerDir = ''

    sExeName = ""

    sApplicationName = parsed_args.appName
    sStableVersion = True
    if parsed_args.versionStable == 'False' or parsed_args.versionStable == 'false':
        sStableVersion = False

    clean = True
    if parsed_args.clean == 'False' or parsed_args.clean == 'false':
        clean = False

    if parsed_args.sExportPass is not None and parsed_args.sExportUser is not None:
        clientSvn.set_default_username(parsed_args.sExportUser)
        clientSvn.set_default_password(parsed_args.sExportPass)

    if sStableVersion:
        sApplicationVersion = GetLatestTag('application/' + sApplicationName)
        sExeName = sApplicationVersion
    else:
        sApplicationVersion = 'trunk'
        latest = GetLatestTag('application/' + sApplicationName)
        latest = str(int(latest.replace('.', '')) + 100)
        sExeName = latest[:4] + '.' + latest[4:6] + '.' + latest[6:]
    if os.path.isdir(sPublishDir + '/../tmp'):
        shutil.rmtree(sPublishDir + '/../tmp')
    os.mkdir(sPublishDir + '/../tmp')
    PurgeTree(sPublishDir)

    if os.path.isfile(sPublishDir + '/../__init__.py'):
        if os.path.isfile(sPublishDir + '/../main.py'):
            os.remove(sPublishDir + '/../main.py')
        os.rename(sPublishDir + '/../__init__.py', sPublishDir + '/../main.py')
    sExeName = 'setup_' + sApplicationName + '-' + sExeName

    print("Création de l'application " + sApplicationName)
    print("Version : " + sApplicationVersion)

    # Recherche des dépendances
    print("Recherche des dépendances")
    SearchDependency("application", sApplicationName)

    bOnlySchema = False
    if len(ressourceDict) <= 2:
        if 'schemasCollection' in ressourceDict:
            bOnlySchema = True

    if sApplicationVersion == 'trunk':
        ChangeVersionToTrunk(ressourceDict)

    # Création du dossier ressources
    if not os.path.isdir(sPublishDir + '/../dist'):
        os.mkdir(sPublishDir + '/../dist')
    os.mkdir(sPublishDir)
    os.mkdir(sPublishDir + '/dependencies')
    # Téléchargement des dépendances
    GetDependency(parsed_args.os, bOnlySchema)

    # Écrire le fichier install.conf
    WriteInstallConf()

    # Écrire les versions.inc
    WriteVersionInc()

    # Récupère les changeLogs liés à l'application
    if not bOnlySchema:
        GetChangeLog(ressourceDict)
        if 'application' in ressourceDict:
            if ressourceDict['application']['name'] != 'gmc':
                # Compilation du javascript
                CompilJS(parsed_args.pack)

    sExeName += '.b' + str(highestBuild)

    if parsed_args.pack in ('debug', 'both'):
        # Suppression des répertoires non necessaires à la version compilé
        if not bOnlySchema:
            if 'application' in ressourceDict:
                CleanCompilJSDebug()
        # Compilation de l'application
        if parsed_args.os in ('windows', 'both'):
            CompileExe(sExeName + '-debug-pack', sPyinstallerDir, bOnlySchema, sOutputDir)
        if parsed_args.os in ('linux', 'both'):
            CompilLinux(sExeName + '-debug-pack')

    if parsed_args.pack in ('normal', 'both'):
        # Suppression des répertoires non necessaires à la version compilé
        if not bOnlySchema:
            if 'application' in ressourceDict:
                CleanCompilJS()
        # Compilation de l'application
        if parsed_args.os in ('windows', 'both'):
            CompileExe(sExeName, sPyinstallerDir, bOnlySchema, sOutputDir)
        # Compilation de l'application pour Linux
        if parsed_args.os in ('linux', 'both'):
            CompilLinux(sExeName)

    os.rename(sPublishDir + '/../main.py', sPublishDir + '/../__init__.py')
    return clean


# Permet de récupérer le dernier tag disponible
# src, indique le path svn à rechercher
def GetLatestTag(src):
    #if bOnlineSVN:
    tagsList = clientSvn.ls(sSvnServerUrl + '/' + src + '/tags')
    #else:
    #	print(sSvnServerLocal)
    #	tagsList = os.listdir(os.path.join(sSvnServerLocal, src, 'tags'))

    latestTag = '2017.00.00'
    for tag in tagsList:
        #if bOnlineSVN:
        currentTag = tag.name[len(sSvnServerUrl + '/' + src + '/tags'):].strip('\/')
        #else:
        #	currentTag = tag
        if int(str(currentTag).replace('.', '')) > int(str(latestTag).replace('.', '')):
            latestTag = currentTag
    return latestTag


# Fonction récursive permettant de creer un dictionnaire contenant toutes les dépendances
def SearchDependency(nature, name, objectSchema=''):

    if nature + name not in sourceDict:
        sourceDict.append(nature + name)

        if objectSchema != '':
            if objectSchema == 'vas':
                src = 'vas'
            else:
                src = 'web_services/' + objectSchema
        else:
            src = (nature + '/' + name).strip('/')

        version = 'trunk'
        if sApplicationVersion == 'trunk':
            src += '/trunk'
        else:
            version = GetLatestTag(src)
            src += '/tags/' + version

        ressource = {'version': version}
        if name != '':
            ressource['name'] = name
        if objectSchema != '':
            ressource['object'] = objectSchema
        print("nature = " + nature)

        if nature in ('application', 'vas', 'core'):
            ressourceDict[nature] = {}
            ressourceDict[nature] = ressource
        elif nature == 'modules':
            if 'modulesCollection' not in ressourceDict:
                ressourceDict['modulesCollection'] = {}
                ressourceDict['modulesCollection']['modules'] = []
            ressourceDict['modulesCollection']['modules'].append(ressource)
        elif nature == 'web_services':
            if 'web_servicesCollection' not in ressourceDict:
                ressourceDict['web_servicesCollection'] = {}
                ressourceDict['web_servicesCollection']['web_services'] = []
            ressourceDict['web_servicesCollection']['web_services'].append(ressource)
        elif nature == 'schema':
            if 'schemasCollection' not in ressourceDict:
                ressourceDict['schemasCollection'] = {}
                ressourceDict['schemasCollection']['schemas'] = []
            ressourceDict['schemasCollection']['schemas'].append(ressource)

        result = ReadFromSVN(src + '/_install/dependency.xml')

        if result != '':
            dictXml = xmldict.xml_to_dict(result.decode('UTF-8'))
            if objectSchema != '':
                dictXml['installer'] = dictXml['installer']['schema']

            if 'dependenciesCollection' in dictXml['installer']:
                if type(dictXml['installer']['dependenciesCollection']['dependency']).__name__ != 'list':
                    tmp = dictXml['installer']['dependenciesCollection']['dependency']
                    dictXml['installer']['dependenciesCollection']['dependency'] = []
                    dictXml['installer']['dependenciesCollection']['dependency'].append(tmp)

            if 'schema' in dictXml['installer']:
                if 'dependenciesCollection' in dictXml['installer']['schema']:
                    if type(dictXml['installer']['schema']['dependenciesCollection']['dependency']).__name__ != 'list':
                        tmp = dictXml['installer']['schema']['dependenciesCollection']['dependency']
                        dictXml['installer']['schema']['dependenciesCollection']['dependency'] = []
                        dictXml['installer']['schema']['dependenciesCollection']['dependency'].append(tmp)

                tmp = {}
                tmp['name'] = dictXml['installer']['schema']['name']
                tmp['nature'] = 'schema'
                tmp['version'] = dictXml['installer']['schema']['version']
                tmp['object'] = nature if name == '' else name
                if 'dependenciesCollection' not in dictXml['installer']:
                    dictXml['installer']['dependenciesCollection'] = {}
                    dictXml['installer']['dependenciesCollection']['dependency'] = []
                dictXml['installer']['dependenciesCollection']['dependency'].append(tmp)

            if 'ressourcesCollection' in dictXml['installer']:
                if type(dictXml['installer']['ressourcesCollection']['ressource']).__name__ != 'list':
                    tmp = dictXml['installer']['ressourcesCollection']['ressource']
                    dictXml['installer']['ressourcesCollection']['ressource'] = []
                    dictXml['installer']['ressourcesCollection']['ressource'].append(tmp)

            if 'dependenciesCollection' in dictXml['installer']:
                ressource['dependenciesCollection'] = dictXml['installer']['dependenciesCollection']
                natureDep = nameDep = objectDep = ''
                for dependency in ressource['dependenciesCollection']['dependency']:
                    if 'nature' in dependency:
                        natureDep = dependency['nature']
                    if 'name' in dependency:
                        nameDep = dependency['name']
                    if 'object' in dependency:
                        objectDep = dependency['object']
                    if not natureDep.startswith('extern'):
                        SearchDependency(natureDep, nameDep, objectDep)
                    else:
                        if nameDep not in lDepExtern:
                            lDepExtern[nameDep] = {'nature': nature, 'wsName': name, 'name': nameDep}
                            if 'location' in dependency:
                                lDepExtern[nameDep]['location'] = dependency['location']

                            #if lDepExtern[nameDep]['wsName'] == '' or not lDepExtern[nameDep]['name'].startswith(lDepExtern[nameDep]['wsName']):
                            #    nature = 'vas'
                            #    name = ''
                            # SearchDependency(nature, name, '0', nameDep)

            if 'schema' in dictXml['installer']:
                SearchDependency('schema', dictXml['installer']['schema']['name'], nature)


# Téléchargement des dépendances
def GetDependency(osDest, bOnlySchema):
    global lHiddenImports
    lHiddenImports.append("'ressources'")
    lHiddenImports.append("'ressources.dependencies'")
    print("Download from SVN")
    print("Extern Dependencies")
    if lDepExtern != {}:
        for dep in lDepExtern.values():
            if dep['wsName'] != '' and dep['name'].startswith(dep['wsName']):
                src = dep['nature'] + '/' + dep['wsName']
            else:
                src = 'vas'

            if sApplicationVersion == 'trunk':
                src += '/trunk'
            else:
                latestTag = GetLatestTag(src)
                src += '/tags/' + latestTag

            GetFromSVN(src + '/_install/dependencies/dep_' + dep['name'] + '.py', 'dependencies')
            if bOnlineSVN:
                if lsFromSVN(src + '/_install/dependencies/' + dep['name']) != '':
                    GetFromSVN(src + '/_install/dependencies/' + dep['name'], os.path.join('dependencies', dep['name'], '_install'))
            else:
                if os.path.isdir(os.path.join(sSvnServerLocal, src, '_install', 'dependencies', dep['name'])):
                    GetFromSVN(os.path.join(src, '_install', 'dependencies', dep['name']), os.path.join('dependencies', dep['name'], '_install'))

            # Download complementary ressources
            DownloadFileDependency(dep, osDest)
            # Get apache Conf
            GetApacheConf(dep, osDest)

            # Récupérer les apache.conf etc...
            dest = sPublishDir + '/dependencies/' + dep['name']
            if os.path.isdir(dest + '/_install'):
                CopyTree(dest + '/_install', dest)
                DeleteFile(dest + '/dependency.xml')
                PurgeTree(dest + '/_install')

            hiddenImport = "'ressources.dependencies.dep_" + dep['name'] + "'"
            if hiddenImport not in lHiddenImports:
                lHiddenImports.append(hiddenImport)

    if not bOnlySchema:
        print("...application")
        if "application" in ressourceDict:
            version = ressourceDict['application']['version']
            if version == 'trunk':
                src = "application/" + sApplicationName + "/trunk"
            else:
                src = "application/" + sApplicationName + "/tags/" + version

            dest = "app/" + sApplicationName + "/conf"
            GetFromSVN(src, dest)

            if not os.path.isdir(sPublishDir + '/app/complement'):
                os.mkdir(sPublishDir + '/app/complement')
            apacheSrc = sPublishDir + '/' + dest + '/_install/apache.conf'
            if os.path.isfile(apacheSrc):
                AppendFile(apacheSrc, sPublishDir + '/app/complement/apache.conf')
            listModuleApacheSrc = sPublishDir + '/' + dest + '/_install/listModuleApache.txt'
            if os.path.isfile(listModuleApacheSrc):
                AppendFile(listModuleApacheSrc, sPublishDir + '/app/complement/listModuleApache.txt')

        print("...core")
        if "core" in ressourceDict:
            version = ressourceDict['core']['version']
            if version == 'trunk':
                src = "core/trunk"
            else:
                latestTag = GetLatestTag('core')
                src = 'core/tags/' + latestTag

            dest = 'app/' + sApplicationName
            GetFromSVN(src, dest)
            apacheSrc = sPublishDir + '/' + dest + '/_install/apache.conf'
            if os.path.isfile(apacheSrc):
                AppendFile(apacheSrc, sPublishDir + '/app/complement/apache.conf')
            listModuleApacheSrc = sPublishDir + '/' + dest + '/_install/listModuleApache.txt'
            if os.path.isfile(listModuleApacheSrc):
                AppendFile(listModuleApacheSrc, sPublishDir + '/app/complement/listModuleApache.txt')

        print("...modules")
        if "modulesCollection" in ressourceDict:
            for module in ressourceDict['modulesCollection']['modules']:
                version = module['version']
                name = module['name']
                print("......" + name)
                if version == 'trunk':
                    src = "modules/" + name + "/trunk"
                else:
                    src = "modules/" + name + "/tags/" + version

                dest = "app/" + sApplicationName + "/modules/" + name
                GetFromSVN(src, dest)
                apacheSrc = sPublishDir + '/' + dest + '/_install/apache.conf'
                if os.path.isfile(apacheSrc):
                    AppendFile(apacheSrc, sPublishDir + '/app/complement/apache.conf')
                listModuleApacheSrc = sPublishDir + '/' + dest + '/_install/listModuleApache.txt'
                if os.path.isfile(listModuleApacheSrc):
                    AppendFile(listModuleApacheSrc, sPublishDir + '/app/complement/listModuleApache.txt')

        print("...vas")
        if "vas" in ressourceDict:
            version = ressourceDict['vas']['version']
            if version == 'trunk':
                src = "vas/trunk/"
            else:
                src = "vas/tags/" + version

            dest = "vas/core/"
            GetFromSVN(src, dest)

            if not os.path.isdir(sPublishDir + '/vas/complement'):
                os.mkdir(sPublishDir + '/vas/complement')
            if not os.path.isdir(sPublishDir + '/vas/complement/vas'):
                os.mkdir(sPublishDir + '/vas/complement/vas')

            apacheSrc = sPublishDir + '/' + dest + '/_install/apache.conf'
            if os.path.isfile(apacheSrc):
                shutil.copy(apacheSrc, sPublishDir + '/vas/complement/vas/apache.conf')
            listModuleApacheSrc = sPublishDir + '/' + dest + '/_install/listModuleApache.txt'
            if os.path.isfile(listModuleApacheSrc):
                shutil.copy(listModuleApacheSrc, sPublishDir + '/vas/complement/vas/listModuleApache.txt')

        print("...web_services")
        if "web_servicesCollection" in ressourceDict:
            for webService in ressourceDict['web_servicesCollection']['web_services']:
                version = webService['version']
                name = webService['name']
                print("......" + name)
                if version == 'trunk':
                    src = "web_services/" + name + "/trunk"
                else:
                    src = "web_services/" + name + "/tags/" + version

                dest = "vas/web_services/" + name
                GetFromSVN(src, dest)

                if not os.path.isdir(sPublishDir + '/vas/complement/' + name):
                    os.mkdir(sPublishDir + '/vas/complement/' + name)
                apacheSrc = sPublishDir + '/' + dest + '/_install/apache.conf'
                if os.path.isfile(apacheSrc):
                    shutil.copy(apacheSrc, sPublishDir + '/vas/complement/' + name + '/apache.conf')
                listModuleApacheSrc = sPublishDir + '/' + dest + '/_install/listModuleApache.txt'
                if os.path.isfile(listModuleApacheSrc):
                    shutil.copy(listModuleApacheSrc, sPublishDir + '/vas/complement/' + name + '/listModuleApache.txt')

    if 'schemasCollection' in ressourceDict:
        if not os.path.isdir(sPublishDir + '/vas/complement'):
            os.makedirs(sPublishDir + '/vas/complement')
        for schema in ressourceDict['schemasCollection']['schemas']:
            GetSqlFromSVN(schema)


def GetApacheConf(dep, osDest):
    dest = sPublishDir + '/dependencies/' + dep['name']

    apacheSrc = dest + '/_install/windows/apache.conf'
    if os.path.isfile(apacheSrc) and osDest in ('windows', 'both'):
        if not os.path.isdir(sPublishDir + '/dependencies/complement/windows/' + dep['name']):
            os.makedirs(sPublishDir + '/dependencies/complement/windows/' + dep['name'])
        shutil.copy(apacheSrc, sPublishDir + '/dependencies/complement/windows/' + dep['name'] + '/apache.conf')
        DeleteFile(apacheSrc)

    apacheSrc = dest + '/_install/linux/apache.conf'
    if os.path.isfile(apacheSrc) and osDest in ('linux', 'both'):
        if not os.path.isdir(sPublishDir + '/dependencies/complement/linux/' + dep['name']):
            os.makedirs(sPublishDir + '/dependencies/complement/linux/' + dep['name'])
        shutil.copy(apacheSrc, sPublishDir + '/dependencies/complement/linux/' + dep['name'] + '/apache.conf')
        DeleteFile(apacheSrc)

    apacheSrc = dest + '/_install/apache.conf'
    if os.path.isfile(apacheSrc):
        if not os.path.isdir(sPublishDir + '/dependencies/complement/' + dep['name']):
            os.makedirs(sPublishDir + '/dependencies/complement/' + dep['name'])
        shutil.copy(apacheSrc, sPublishDir + '/dependencies/complement/' + dep['name'] + '/apache.conf')
        DeleteFile(apacheSrc)


def DownloadFileDependency(dep, osDest):
    if 'location' in dep:
        if dep['location'] is not None:
            destPath = sPublishDir + '/dependencies/' + dep['name']
            bDownload = False

            if bOnlineRessources:
                pathRessource = sRessourcesPathOnline + '/' + dep['location']
                if requests.get(pathRessource + '/windows').status_code in (200, 403):
                    if osDest in ('windows', 'both'):
                        DownloadHttpFile(pathRessource + '/windows/' + dep['name'] + '.zip', os.path.join(destPath, 'windows'))
                    bDownload = True
                if requests.get(pathRessource + '/linux').status_code in (200, 403):
                    if osDest in ('linux', 'both'):
                        DownloadHttpFile(pathRessource + '/linux/' + dep['name'] + '.tar.gz', os.path.join(destPath, '\linux'))
                    bDownload = True
                if not bDownload:
                    DownloadHttpFile(pathRessource + '/' + dep['name'] + '.zip', destPath)
            else:
                pathRessource = os.path.join(sRessourcesPathLocal, dep['location'])
                if os.path.isdir(os.path.join(pathRessource, 'windows')):
                    if osDest in ('windows', 'both'):
                        DownloadLocalFile(os.path.join(pathRessource, 'windows', dep['name'] + '.zip'), os.path.join(destPath, 'windows'))
                    bDownload = True
                if os.path.isdir(os.path.join(pathRessource, 'linux')):
                    if osDest in ('linux', 'both'):
                        DownloadLocalFile(os.path.join(pathRessource, 'linux', dep['name'] + '.tar.gz'), os.path.join(destPath, 'linux'))
                    bDownload = True
                if not bDownload:
                    DownloadLocalFile(os.path.join(pathRessource, dep['name'] + '.zip'), destPath)


def DownloadLocalFile(src, dest):
    if not os.path.isdir(dest):
        os.makedirs(dest)
    shutil.copy(src, dest)

def DownloadHttpFile(src, dest):
    local_filename = src.split('/')[-1]
    # NOTE the stream=True parameter
    r = requests.get(src, stream=True)
    if not os.path.isdir(dest):
        os.makedirs(dest)
    with open(dest + '/' + local_filename, 'wb') as f:
        for chunk in r.iter_content(chunk_size=1024):
            if chunk:  # filter out keep-alive new chunks
                f.write(chunk)


def AppendFile(src, dest):
    fileDest = open(dest, 'w')
    if os.path.isfile(dest) and os.path.getsize(dest) != 0:
        fileDest.write("\n\n")
    shutil.copyfileobj(open(src, 'r'), fileDest)
    fileDest.close()


def WriteInstallConf():
    writeDict = CleanDependency()
    fichier = open(sPublishDir + "/installConf.xml", "w", encoding="utf-8")
    fichier.write('<?xml version="1.0" encoding="UTF-8"?>\n')
    fichier.write("<installer>" + xmldict.dict_to_xml(writeDict) + "</installer>")
    fichier.close()


def CleanDependency():
    writeDict = dict(ressourceDict)
    if 'core' in writeDict:
        for dependency in writeDict['core']['dependenciesCollection']['dependency']:
            if dependency['nature'] not in ('modules', 'core'):
                writeDict['application']['dependenciesCollection']['dependency'].append(dependency)

    if 'modulesCollection' in writeDict:
        for module in writeDict['modulesCollection']['modules']:
            if 'dependenciesCollection' in module:
                for dependency in module['dependenciesCollection']['dependency']:
                    if dependency['nature'] not in ('modules', 'core'):
                        writeDict['application']['dependenciesCollection']['dependency'].append(dependency)

    writeDict.pop("core", None)
    writeDict.pop("modulesCollection", None)

    dependenciesList = []
    for dependency in writeDict['application']['dependenciesCollection']['dependency']:
        if dependency['nature'] not in ('modules', 'core'):
            dependenciesList.append(dependency)

    writeDict['application']['dependenciesCollection'].pop("dependency", None)
    writeDict['application']['dependenciesCollection']['dependency'] = dependenciesList
    return writeDict


def GetSqlFromSVN(schema):
    if not os.path.isfile(sPublishDir + '/vas/complement/' + schema['object'] + '/sqlQueries.xml'):
        src = schema['object']
        if schema['object'] != 'vas':
            src = 'web_services/' + src

        # Vérif si le fichier est présent
        if sApplicationVersion == 'trunk':
            src += '/trunk'
        else:
            # get latest tag
            latestTag = GetLatestTag(src)
            src += '/tags/' + latestTag

        srcSql = src + '/sql/sqlQueries.xml'
        if src.startswith('vas'):
            src += '/rest'
        srcVersionInc = src + '/conf/version.inc'
        if not os.path.isdir(sPublishDir + '/vas/complement/' + schema['object']):
            os.mkdir(sPublishDir + '/vas/complement/' + schema['object'])
        GetFromSVN(srcSql, 'vas/complement/' + schema['object'] + '/sqlQueries.xml')
        GetFromSVN(srcVersionInc, 'vas/complement/' + schema['object'] + '/version.inc')

        if 'dependenciesCollection' in schema:
            for schemaDep in schema['dependenciesCollection']['dependency']:
                if schemaDep['nature'] == 'schema':
                    GetSqlFromSVN(schemaDep)


def GetFromSVN(src, dest):
    print("source = " + src)
    dest = os.path.join(sPublishDir, dest)
    if bOnlineSVN:
        revision = clientSvn.export(sSvnServerUrl + "/" + src, dest, True)
    else:
        src = os.path.join(sSvnServerLocal, src)
        if os.path.isfile(src):
            shutil.copy(src, dest)
        else:
            recursive_overwrite(src, dest)
    pass

def recursive_overwrite(src, dest, ignore=None):
    if os.path.isdir(src):
        if not os.path.isdir(dest):
            os.makedirs(dest)
        files = os.listdir(src)
        if ignore is not None:
            ignored = ignore(src, files)
        else:
            ignored = set()
        for f in files:
            if f not in ignored:
                recursive_overwrite(os.path.join(src, f), 
                                    os.path.join(dest, f), 
                                    ignore)
    else:
        shutil.copyfile(src, dest)

def ReadFromSVN(src):
    print("Read from SVN")
    print("source = " + src)
    try:
        if bOnlineSVN:
            result = clientSvn.cat(sSvnServerUrl + "/" + src)
        else:
            with open(os.path.join(sSvnServerLocal, src), mode='rb') as file:
                result = file.read()
    except Exception:
        print("file not found = " + sSvnServerUrl + "/" + src)
        result = ''
    return result


def lsFromSVN(src):
    print("Read from SVN")
    print("source = " + src)
    try:
        result = clientSvn.ls(sSvnServerUrl + "/" + src)
    except Exception:
        print("file not found = " + sSvnServerUrl + "/" + src)
        result = ''
    return result


def IsApacheConfExist(src):
    print('Read from SVN')
    print('source = ' + src)
    try:
        clientSvn.cat(sSvnServerUrl + "/" + src)
    except Exception:
        return False
    return True


def ReplaceVersionInFileSvn(path, infoVersion):
    global highestBuild
    if infoVersion['build'] > highestBuild:
        highestBuild = infoVersion['build']

    openedFile = open(path, 'r', encoding="utf-8")
    dataFromFile = openedFile.read()
    openedFile.close()
    # replacing expression
    dataFromFile = dataFromFile.replace('[VERSION]', infoVersion['version'])
    dataFromFile = dataFromFile.replace('[BUILD]', str(infoVersion['build']))
    dataFromFile = dataFromFile.replace('[MONTH_YEAR]', infoVersion['date'])
    # writing result
    openedFile = open(path, 'w', encoding="utf-8")
    openedFile.write(dataFromFile)
    openedFile.close()
    return [0, '']


def GetApplicationBuild():
    buildApp = 0
    timestampApp = 0
    if sApplicationVersion == 'trunk':
        # Build Application
        pathSvn = sSvnServerUrl + '/application/' + ressourceDict['application']['name'] + '/trunk'
        result = clientSvn.log(pathSvn, revision_start=pysvn.Revision(pysvn.opt_revision_kind.head), revision_end=pysvn.Revision(pysvn.opt_revision_kind.number, 0), limit=1)
        build = result[0].data['revision'].number
        if build > buildApp:
            buildApp = build
        timestamp = result[0].data['date']
        if timestamp > timestampApp:
            timestampApp = timestamp

        # Build Core
        pathSvn = sSvnServerUrl + '/core/trunk'
        result = clientSvn.log(pathSvn, revision_start=pysvn.Revision(pysvn.opt_revision_kind.head), revision_end=pysvn.Revision(pysvn.opt_revision_kind.number, 0), limit=1)
        build = result[0].data['revision'].number
        if build > buildApp:
            buildApp = build
        timestamp = result[0].data['date']
        if timestamp > timestampApp:
            timestampApp = timestamp
        # Build Modules
        if 'modulesCollection' in ressourceDict:
            for module in ressourceDict['modulesCollection']['modules']:
                pathSvn = sSvnServerUrl + '/modules/' + module['name'] + '/trunk'
                result = clientSvn.log(pathSvn, revision_start=pysvn.Revision(pysvn.opt_revision_kind.head), revision_end=pysvn.Revision(pysvn.opt_revision_kind.number, 0), limit=1)
                build = result[0].data['revision'].number
                if build > buildApp:
                    buildApp = build
                timestamp = result[0].data['date']
                if timestamp > timestampApp:
                    timestampApp = timestamp
    else:
        pathSvn = sSvnServerUrl + '/application/' + ressourceDict['application']['name'] + '/tags/' + GetLatestTag('/application/' + ressourceDict['application']['name'])
        result = clientSvn.log(pathSvn, revision_start=pysvn.Revision(pysvn.opt_revision_kind.head), revision_end=pysvn.Revision(pysvn.opt_revision_kind.number, 0), limit=1)
        build = result[0].data['revision'].number
        if build > buildApp:
            buildApp = build
        timestamp = result[0].data['date']
        if timestamp > timestampApp:
            timestampApp = timestamp

        # Build Core
        pathSvn = sSvnServerUrl + '/core/tags/' + GetLatestTag('/core')
        result = clientSvn.log(pathSvn, revision_start=pysvn.Revision(pysvn.opt_revision_kind.head), revision_end=pysvn.Revision(pysvn.opt_revision_kind.number, 0), limit=1)
        build = result[0].data['revision'].number
        if build > buildApp:
            buildApp = build
        timestamp = result[0].data['date']
        if timestamp > timestampApp:
            timestampApp = timestamp
        # Build Modules
        if 'modulesCollection' in ressourceDict:
            for module in ressourceDict['modulesCollection']['modules']:
                pathSvn = sSvnServerUrl + '/modules/' + module['name'] + '/tags/' + GetLatestTag('/modules/' + module['name'])
                result = clientSvn.log(pathSvn, revision_start=pysvn.Revision(pysvn.opt_revision_kind.head), revision_end=pysvn.Revision(pysvn.opt_revision_kind.number, 0), limit=1)
                build = result[0].data['revision'].number
                if build > buildApp:
                    buildApp = build
                timestamp = result[0].data['date']
                if timestamp > timestampApp:
                    timestampApp = timestamp

    info = {}
    info['date'] = timestampApp
    info['build'] = buildApp
    return info


def WriteVersionInc():

    infoVersion = {}
    infoVersion['version'] = ressourceDict['application']['version']
    info = GetApplicationBuild()
    infoVersion['date'] = datetime.datetime.fromtimestamp(info['date']).strftime('%m_%Y')
    infoVersion['build'] = info['build']
    # updating properties.json
    path = sPublishDir + '/app/' + ressourceDict['application']['name'] + '/conf/properties.json'
    if os.path.isfile(path):
        result = ReplaceVersionInFileSvn(path, infoVersion)
        if result[0] != 0:
            return result

    if 'vas' in ressourceDict:
        if sApplicationVersion == 'trunk':
            pathSvn = sSvnServerUrl + '/vas/trunk'
        else:
            pathSvn = sSvnServerUrl + '/vas/tags/' + GetLatestTag('/vas')
        result = clientSvn.log(pathSvn, revision_start=pysvn.Revision(pysvn.opt_revision_kind.head), revision_end=pysvn.Revision(pysvn.opt_revision_kind.number, 0), limit=1)
        infoVersion = {}
        infoVersion['version'] = ressourceDict['vas']['version']
        infoVersion['date'] = datetime.datetime.fromtimestamp(result[0].data['date']).strftime('%m_%Y')
        infoVersion['build'] = result[0].data['revision'].number
        path = sPublishDir + '/vas/core/rest/conf/version.inc'
        if os.path.isfile(path):
            # updating version.inc
            result = ReplaceVersionInFileSvn(path, infoVersion)
            if result[0] != 0:
                return result

    if 'web_servicesCollection' in ressourceDict:
        for ws in ressourceDict['web_servicesCollection']['web_services']:
            if sApplicationVersion == 'trunk':
                pathSvn = sSvnServerUrl + '/web_services/' + ws['name'] + '/trunk'
            else:
                pathSvn = sSvnServerUrl + '/web_services/' + ws['name'] + '/tags/' + GetLatestTag('/web_services/' + ws['name'])
            result = clientSvn.log(pathSvn, revision_start=pysvn.Revision(pysvn.opt_revision_kind.head), revision_end=pysvn.Revision(pysvn.opt_revision_kind.number, 0), limit=1)
            infoVersion = {}
            infoVersion['version'] = ws['version']
            infoVersion['date'] = datetime.datetime.fromtimestamp(result[0].data['date']).strftime('%m_%Y')
            infoVersion['build'] = result[0].data['revision'].number
            # updating version.inc
            path = sPublishDir + '/vas/web_services/' + ws['name'] + '/conf/version.inc'
            if os.path.isfile(path):
                result = ReplaceVersionInFileSvn(path, infoVersion)
                if result[0] != 0:
                    return result

    if 'schemasCollection' in ressourceDict:
        for schema in ressourceDict['schemasCollection']['schemas']:
            if schema['object'] == 'vas':
                objectPath = 'vas'
            else:
                objectPath = 'web_services/' + schema['object']

            if sApplicationVersion == 'trunk':
                pathSvn = sSvnServerUrl + '/' + objectPath + '/trunk'
            else:
                pathSvn = sSvnServerUrl + '/' + objectPath + '/tags/' + GetLatestTag(objectPath)
            result = clientSvn.log(pathSvn, revision_start=pysvn.Revision(pysvn.opt_revision_kind.head), revision_end=pysvn.Revision(pysvn.opt_revision_kind.number, 0), limit=1)
            infoVersion = {}
            infoVersion['version'] = schema['version']
            infoVersion['date'] = datetime.datetime.fromtimestamp(result[0].data['date']).strftime('%m_%Y')
            infoVersion['build'] = result[0].data['revision'].number
            # updating version.inc
            path = sPublishDir + '/vas/complement/' + schema['object'] + '/version.inc'
            if os.path.isfile(path):
                result = ReplaceVersionInFileSvn(path, infoVersion)
                if result[0] != 0:
                    return result


def DeleteFile(path):
    if os.path.isfile(path):
        os.remove(path)


def CompilJS(pack):
    confPath = 'app/' + sApplicationName + '/conf'
    GetFromSVN('closure', confPath + '/closure')
    file = open(sPublishDir + '/' + confPath + '/compil.cmd', 'w')
    file.write('@echo off\n')
    file.write('%~d0\n')
    file.write('cd %~dp0\n')
    file.write('call npm install grunt --save\n')
    file.write('call npm install -g grunt-cli\n')
    file.write('call npm install grunt-closure-tools --save\n')
    file.write('call npm install google-closure-compiler@20160911.0.0 --save\n')
    file.write('call npm install google-closure-library@20160911.0.0 --save\n')
    if pack in ('debug', 'both'):
        file.write('call grunt generate-deps\n')
    file.write('call grunt compile\n')
    file.close()
    os.system(sPublishDir + '/' + confPath + '/compil.cmd')
    if not os.path.isfile(sPublishDir + '/app/' + sApplicationName + '/javascript/' + sApplicationName + '.min.js'):
        raise "La compilation de " + sApplicationName + ".min.js a échoué"


def CleanCompilJSDebug():
    confPath = 'app/' + sApplicationName + '/conf'
    PurgeTree(sPublishDir + '/' + confPath + '/node_modules/.bin')
    PurgeTree(sPublishDir + '/' + confPath + '/node_modules/angular-mocks')
    PurgeTree(sPublishDir + '/' + confPath + '/node_modules/google-closure-compiler')
    PurgeTree(sPublishDir + '/' + confPath + '/node_modules/grunt')
    PurgeTree(sPublishDir + '/' + confPath + '/node_modules/grunt-closure-tools')


def CleanCompilJS():
    confPath = 'app/' + sApplicationName + '/conf'
    PurgeTree(sPublishDir + '/' + confPath + '/node_modules')
    PurgeTree(sPublishDir + '/' + confPath + '/closure')
    DeleteFile(sPublishDir + '/' + confPath + '/compil.cmd')

    DeleteFile(sPublishDir + 'app/' + sApplicationName + '/javascript/' + sApplicationName + '.deps.js')

    CleanFolderInstall(sPublishDir + '/app/' + ressourceDict['application']['name'] + '/conf')
    CleanFolderInstall(sPublishDir + '/app/' + ressourceDict['application']['name'])

    for module in ressourceDict['modulesCollection']['modules']:
        CleanFolderInstall(sPublishDir + '/app/' + ressourceDict['application']['name'] + '/modules/' + module['name'])

    CleanFolderInstall(sPublishDir + '/vas/core')
    for ws in ressourceDict['web_servicesCollection']['web_services']:
        CleanFolderInstall(sPublishDir + '/vas/web_services/' + ws['name'])


def CleanFolderInstall(path):
    if os.path.isdir(path + '/_install'):
        if os.path.isfile(path + '/_install/fileToDelete.txt'):
            with open(path + '/_install/fileToDelete.txt', 'r', encoding="utf-8") as file:
                filesToDelete = file.read()
            for fileToDelete in filesToDelete.split('\n'):
                DeleteFile(path + '/' + fileToDelete)
        if os.path.isfile(path + '/_install/folderToDelete.txt'):
            with open(path + '/_install/folderToDelete.txt', 'r', encoding="utf-8") as file:
                foldersToDelete = file.read()
            for folderToDelete in foldersToDelete.split('\n'):
                PurgeTree(path + '/' + folderToDelete)

        if os.path.isfile(path + '/_install/windows/fileToDelete.txt'):
            with open(path + '/_install/windows/fileToDelete.txt', 'r', encoding="utf-8") as file:
                filesToDelete = file.read()
            for fileToDelete in filesToDelete.split('\n'):
                DeleteFile(path + '/windows/' + fileToDelete)
        if os.path.isfile(path + '/_install/windows/folderToDelete.txt'):
            with open(path + '/_install/windows/folderToDelete.txt', 'r', encoding="utf-8") as file:
                foldersToDelete = file.read()
            for folderToDelete in foldersToDelete.split('\n'):
                PurgeTree(path + '/windows/' + folderToDelete)

        if os.path.isfile(path + '/_install/linux/fileToDelete.txt'):
            with open(path + '/_install/linux/fileToDelete.txt', 'r', encoding="utf-8") as file:
                filesToDelete = file.read()
            for fileToDelete in filesToDelete.split('\n'):
                DeleteFile(path + '/linux/' + fileToDelete)
        if os.path.isfile(path + '/_install/linux/folderToDelete.txt'):
            with open(path + '/_install/linux/folderToDelete.txt', 'r', encoding="utf-8") as file:
                foldersToDelete = file.read()
            for folderToDelete in foldersToDelete.split('\n'):
                PurgeTree(path + '/linux/' + folderToDelete)
        PurgeTree(path + '/_install')


def CompileExe(sNameExe, pyinstallerDir, bOnlySchema, sOutputDir):
    dirToScan = sPublishDir + '/dependencies'
    if os.path.isdir(dirToScan):
        for folder in os.listdir(dirToScan):
            if os.path.isdir(dirToScan + '/' + folder + '/linux'):
                shutil.move(dirToScan + '/' + folder + '/linux', os.path.dirname(os.path.realpath(__file__)) + '/tmp/' + folder)

    if os.path.isfile(sWorkDir + '/vai_final.spec'):
        os.remove(sWorkDir + '/vai_final.spec')
    f1 = open(sWorkDir + '/vai.spec', 'r')
    f2 = open(sWorkDir + '/vai_final.spec', 'w')

    if sApplicationVersion == 'trunk':
        sNameExe += '_beta'

    for line in f1:
        if bOnlySchema:
            f2.write(line.replace('datas=None,', 'datas=added_files,').replace('block_cipher = None', 'block_cipher = None\nadded_files = [\n(\'[pathSrc]/ressources\', \'ressources\')\n]').replace('[hiddenimports]', ', '.join(lHiddenImports)).replace('[appName]', sNameExe).replace('[pathSrc]', os.path.dirname(os.path.realpath(__file__)).replace('\\', '/')))
        else:
            f2.write(line.replace('[hiddenimports]', ', '.join(lHiddenImports)).replace('[appName]', sNameExe).replace('[pathSrc]', os.path.dirname(os.path.realpath(__file__)).replace('\\', '/')))

    f1.close()
    f2.close()
    if sOutputDir == '':
        sOutputDir = sWorkDir + '/dist'
    os.system(pyinstallerDir + 'pyinstaller.exe -F ' + sWorkDir + '/vai_final.spec --distpath ' + sOutputDir + ' --workpath ' + sWorkDir + '/build')

    if not bOnlySchema:
        if os.path.isfile(sWorkDir + '/dist/' + sNameExe + '.exe'):
            if os.path.isfile(sWorkDir + '/dist/' + sNameExe + '-win.zip'):
                os.remove(sWorkDir + '/dist/' + sNameExe + '-win.zip')

            GetScriptFromSvn('install.cmd', sNameExe)
            GetScriptFromSvn('update.cmd', sNameExe)
            GetScriptFromSvn('uninstall.cmd', sNameExe)

            with zipfile.ZipFile(sWorkDir + '/dist/' + sNameExe + '-win.zip', 'w', zipfile.ZIP_DEFLATED) as myzip:
                myzip.write(sWorkDir + '/dist/' + sNameExe + '.exe', sNameExe + '.exe')
                if os.path.isfile(sWorkDir + '/dist/CHANGE_LOG.txt'):
                    myzip.write(sWorkDir + '/dist/CHANGE_LOG.txt', 'CHANGE_LOG.txt')
                myzip.write(sWorkDir + '/dist/install.cmd', 'install.cmd')
                myzip.write(sWorkDir + '/dist/update.cmd', 'update.cmd')
                myzip.write(sWorkDir + '/dist/uninstall.cmd', 'uninstall.cmd')
                for root, dirs, files in os.walk(sWorkDir + '/ressources'):
                    for file in files:
                        fileRelatif = os.path.join(root, file)[len(sWorkDir) + 1:]
                        myzip.write(os.path.join(root, file), fileRelatif)
            os.remove(sWorkDir + '/dist/' + sNameExe + '.exe')
            os.remove(sWorkDir + '/dist/install.cmd')
            os.remove(sWorkDir + '/dist/update.cmd')
            os.remove(sWorkDir + '/dist/uninstall.cmd')

    dirToScan = os.path.dirname(os.path.realpath(__file__)) + '/tmp/'
    if os.path.isdir(dirToScan):
        for folder in os.listdir(dirToScan):
            shutil.move(dirToScan + '/' + folder, sPublishDir + '/dependencies/' + folder + '/linux')


def GetScriptFromSvn(scriptName, sNameExe):
    GetFromSVN('vai/trunk/scripts/' + scriptName, '../dist/' + scriptName)
    # Read File
    openedFile = open(sPublishDir + '/../dist/' + scriptName, 'r', encoding="utf-8")
    dataFromFile = openedFile.read()
    openedFile.close()
    # replacing expression
    dataFromFile = dataFromFile.replace('[exeName]', sNameExe)
    dataFromFile = dataFromFile.replace('[appName]', sApplicationName)
    sRid = ""
    sRidCommand = ""
    if sApplicationName in ('sigrando', 'vmap'):
        if "cmd" in scriptName:
            sRid = "set srid="
            sRidCommand = "-sql SRID=%srid%"
        else:
            sRid = "srid="
            sRidCommand = "-sql SRID=$srid"
    dataFromFile = dataFromFile.replace('[SRID]', sRid)
    dataFromFile = dataFromFile.replace('[sridCommand]', sRidCommand)
    # writing result
    openedFile = open(sPublishDir + '/../dist/' + scriptName, 'w', encoding="utf-8")
    openedFile.write(dataFromFile)
    openedFile.close()


def CompilLinux(sNameExe):
    dirToScan = sPublishDir + '/dependencies'
    if os.path.isdir(dirToScan):
        for folder in os.listdir(dirToScan):
            if os.path.isdir(dirToScan + '/' + folder + '/windows'):
                shutil.move(dirToScan + '/' + folder + '/windows', os.path.dirname(os.path.realpath(__file__)) + '/tmp/' + folder)

    if os.path.isfile(sWorkDir + '/vai_final_linux.spec'):
        os.remove(sWorkDir + '/vai_final_linux.spec')
    f1 = open(sWorkDir + '/vai.spec', 'r')
    f2 = open(sWorkDir + '/vai_final_linux.spec', 'w')
    pathWindows = os.path.dirname(os.path.realpath(__file__)).replace(':', '').replace('\\', '/')
    path = '/mnt/' + pathWindows[0].lower() + pathWindows[1:]

    if sApplicationVersion == 'trunk':
        sNameExe += '_beta'
    for line in f1:
        f2.write(line.replace('[hiddenimports]', ', '.join(lHiddenImports)).replace('[appName]', sNameExe).replace('[pathSrc]', path))
    f1.close()
    f2.close()
    os.system('bash -c "cd ' + path + ' && pyinstaller -F vai_final_linux.spec"')

    if os.path.isfile('dist/' + sNameExe):
        if os.path.isfile('dist/' + sNameExe + '-linux.zip'):
            os.remove('dist/' + sNameExe + '-linux.zip')

        GetScriptFromSvn('install.sh', sNameExe)
        GetScriptFromSvn('update.sh', sNameExe)
        GetScriptFromSvn('uninstall.sh', sNameExe)
        os.system('bash -c "cd ' + path + '/dist && dos2unix *.sh"')

        with zipfile.ZipFile(sWorkDir + "/dist/" + sNameExe + '-linux.zip', 'w', zipfile.ZIP_DEFLATED) as myzip:
            myzip.write(sWorkDir + '/dist/' + sNameExe, sNameExe)
            if os.path.isfile(sWorkDir + '/dist/CHANGE_LOG.txt'):
                myzip.write(sWorkDir + '/dist/CHANGE_LOG.txt', 'CHANGE_LOG.txt')
            myzip.write(sWorkDir + '/dist/install.sh', 'install.sh')
            myzip.write(sWorkDir + '/dist/update.sh', 'update.sh')
            myzip.write(sWorkDir + '/dist/uninstall.sh', 'uninstall.sh')
            for root, dirs, files in os.walk('ressources'):
                for file in files:
                    myzip.write(os.path.join(root, file))
        os.remove(sWorkDir + '/dist/' + sNameExe)
        os.remove(sWorkDir + '/dist/install.sh')
        os.remove(sWorkDir + '/dist/update.sh')
        os.remove(sWorkDir + '/dist/uninstall.sh')

    if os.path.isdir(dirToScan):
        dirToScan = os.path.dirname(os.path.realpath(__file__)) + '/tmp/'
        for folder in os.listdir(dirToScan):
            shutil.move(dirToScan + '/' + folder, sPublishDir + '/dependencies/' + folder + '/windows')


def PurgeTree(directory):
    if os.path.isdir(directory):
        result = os.system('robocopy /NFL /NDL /NJH /NJS /nc /ns /np /purge ' + sPublishDir + '/../tmp ' + directory)
        if result > 7:
            sys.exit("Error")
        result = os.system('robocopy /NFL /NDL /NJH /NJS /nc /ns /np /S /MOVE ' + directory + ' ' + directory)
        if result > 7:
            sys.exit("Error")


def CopyTree(src, dest, level="all"):
    result = 0
    if level == "all":
        result = os.system('robocopy /NFL /NDL /NJH /NJS /nc /ns /np /E /COPY:D ' + src + ' ' + dest)
    else:
        result = os.system('robocopy /NFL /NDL /NJH /NJS /nc /ns /np /COPY:D /lev:0 ' + src + ' ' + dest)
    if result > 7:
        sys.exit("Error")


def ChangeVersionToTrunk(v, prefix=''):
    if isinstance(v, dict):
        if 'version' in v and 'nature' in v and v['nature'] in ('vas', 'schema', 'web_services', 'modules', 'core'):
            v['version'] = 'trunk'
        for k, v2 in v.items():
            p2 = "{}['{}']".format(prefix, k)
            ChangeVersionToTrunk(v2, p2)
    elif isinstance(v, list):
        for i, v2 in enumerate(v):
            p2 = "{}[{}]".format(prefix, i)
            ChangeVersionToTrunk(v2, p2)


def GetChangeLog(ressourceDict):
    changeLogList = []
    if "vas" in ressourceDict:
        if ressourceDict["vas"]["version"] == "trunk":
            changeLogList.append("vas/trunk")
        else:
            changeLogList.append("vas/tags/" + ressourceDict["vas"]["version"])

    if "core" in ressourceDict:
        if ressourceDict["vas"]["version"] == "trunk":
            changeLogList.append("core/trunk")
        else:
            changeLogList.append("core/tags/" + ressourceDict["core"]["version"])

    if "modulesCollection" in ressourceDict:
        for module in ressourceDict["modulesCollection"]["modules"]:
            if module["version"] == "trunk":
                changeLogList.append("modules/" + module["name"] + "/trunk")
            else:
                changeLogList.append("modules/" + module["name"] + "/tags/" + module["version"])

    if "web_servicesCollection" in ressourceDict:
        for ws in ressourceDict["web_servicesCollection"]["web_services"]:
            if ws["version"] == "trunk":
                changeLogList.append("web_services/" + ws["name"] + "/trunk")
            else:
                changeLogList.append("web_services/" + ws["name"] + "/tags/" + ws["version"])

    dComment = []
    for changeLog in changeLogList:
        tmp = ReadFromSVN(changeLog + '/CHANGE_LOG.txt')
        if tmp != "":
            lines = tmp.decode('UTF-8').split("\n")
            after = False
            for line in lines:
                if line.strip("\r").lstrip('|'):
                    m = re.match(r'b([0-9]*)', line.lstrip('|'))
                    if m:
                        revisionComment = int(m.group(1))
                        after = True
                    if after:
                        dComment.append([revisionComment, line])
    file = open(sPublishDir + '/../dist/CHANGE_LOG.txt', "w", encoding="utf-8")
    file.write('\n')
    file.write('\t\t\t\t+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n')
    file.write('\t\t\t\t+                                                                                   +\n')
    title = "                        "
    title += "VEREMES - Application " + sApplicationName + " change log"
    title = title.ljust(83)
    file.write('\t\t\t\t+' + title + '+\n')
    file.write('\t\t\t\t+                                                                                   +\n')
    file.write('\t\t\t\t+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n')
    file.write('\n')
    file.write('\n')
    for comment in sorted(dComment, reverse=True):
        file.write(comment[1].strip('\n\r') + '\n')
    file.close()


if start():
    PurgeTree(sPublishDir + '/../__pycache__')
    PurgeTree(sPublishDir + '/../build')
    PurgeTree(sPublishDir + '/../ressources')
shutil.rmtree(sPublishDir + '/../tmp')
DeleteFile(sPublishDir + '/../dist/CHANGE_LOG.txt')
DeleteFile(sPublishDir + '/../vai_final.spec')
DeleteFile(sPublishDir + '/../vai_final_linux.spec')
print("Finish")
