# coding: utf-8
import inspect
import subprocess
import json
import os
import sys
import platform
import shutil
import re
import logging
import logging.handlers
import requests
import xmldict
import ctypes

from Dependence import Dependence
from WebService import WebService
from Application import Application
from Vas import Vas
from Schema import Schema
from Installer import Installer
from Uninstaller import Uninstaller
from FileManip import FileManip
from Report import Report
from ApacheTools import ApacheTools
from PostgresTools import PostgresTools


class Launcher(ApacheTools, PostgresTools):

    def __init__(self, args, trad):
        self.args = args
        del args
        self.trad = trad
        del trad
        self.reportDict = {}
        self.objectCheckList = []
        self.webServiceDict = {}
        self.schemaDict = {}
        self.vas = None
        self.application = None

        self.params = {}
        self.params['appDirectory'] = self.args['appDirectory']
        self.params['vasDirectory'] = self.args['vasDirectory']
        if self.args['adminLogin'] == None:
            self.params['adminLogin'] = ''
        else:
            self.params['adminLogin'] = self.args['adminLogin'].lower()
        self.params['adminPswd'] = self.args['adminPswd']
        self.params['installDep'] = self.args['installDep']
        self.params['verbose'] = self.args['verbose']
        self.params['sqlReplace'] = self.args['sqlReplace']
        if getattr(sys, 'frozen', False):
            self.params['ressourcesPath'] = os.path.join(os.path.dirname(os.path.abspath(sys.executable)), 'ressources')
        elif __file__:
            self.params['ressourcesPath'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ressources')

        if not os.path.isdir(self.params['ressourcesPath']):
            self.params['ressourcesPath'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ressources')

        self.params['dependencies'] = os.path.join(self.params['ressourcesPath'], 'dependencies')
        self.params['confFile'] = os.path.join(self.params['ressourcesPath'], 'installConf.xml')

        self.info = {}
        self.info['action'] = self.args['action']
        self.info['name'] = self.args['serviceName']
        self.info['nature'] = self.args['serviceNat']

        self.params['logPath'] = ""
        if self.args['logPath']:
            self.params['logPath'] = self.args['logPath']
        else:
            self.params['logPath'] = os.path.join(os.getcwd(), 'activity.log')

        self.logger = self.Setlogger()

        # setting up file manipulation class
        self.fileManipulator = FileManip(self)

        ApacheTools.__init__(self)
        PostgresTools.__init__(self)

        result = []
        result.append(0)
        if self.info['action'] != 'install' and self.info['nature'] != 'schema':
            result = self.CheckDirectoryPath()
            if result[0] == 0:
                result = self.GetProperties()
            else:
                raise Exception(result[1])

        del self.args
        if self.info['nature'] != 'schema':
            result = self.CheckFreeSpace()

        self.reportDict['commandLine'] = " ".join(sys.argv)
        if result[0] == 0:
            result = self.PreLaunch()
            if result[0] == 0:
                if self.info['action'] != 'uninstall':
                    inst = Installer(self, self.info)
                    result = inst.Launch()
                else:
                    uninst = Uninstaller(self)
                    result = uninst.Launch()

        if result[0] != 0:
            if len(result) > 2:
                self.logger.error(self.trad["Launcher_1"].format(str(result[2][1])))
                self.logger.error(self.trad["Launcher_2"].format(str(result[2][3])))
                self.logger.error(self.trad["Launcher_3"].format(str(result[2][2])))
            self.logger.error(self.trad["Launcher_4"].format(str(result[1])))
            self.reportDict['messageError'] = str(result[1])
            if self.fileManipulator is not None:
                self.fileManipulator.RollBack()

        if self.fileManipulator is not None:
            self.fileManipulator.CleanTraceBack()

        if platform.system() == 'Linux':
            if os.path.isdir(self.params['vasDirectory']):
                result = self.RunCommand(["chown", "-R", "www-data.www-data", self.params['vasDirectory']])
                if result[0] != 0:
                    print(self.trad["Launcher_5"])
            if os.path.isdir(self.params['appDirectory']):
                result = self.RunCommand(["chown", "-R", "www-data.www-data", self.params['appDirectory']])
                if result[0] != 0:
                    print(self.trad["Launcher_6"])
            result = self.RunCommand(['ldconfig'])
            if result[0] != 0:
                return result

        # Creating report
        report = Report(self)
        report.CreateReport()
        if result[0] != 100:
            self.StartApacheService()

        if 'appDirectory' in self.params and self.params['appDirectory'] is not None:
            directory = os.path.dirname(self.params['appDirectory'])
            if os.path.isdir(directory):
                if os.listdir(directory) == []:
                    os.rmdir(directory)

        if 'vasDirectory' in self.params and self.params['vasDirectory'] is not None:
            directory = os.path.dirname(self.params['vasDirectory'])
            if os.path.isdir(directory):
                if os.listdir(directory) == []:
                    os.rmdir(directory)
        if result[0] == 0:
            self.logger.info(self.trad["Launcher_7"])
        else:
            self.logger.critical(self.trad["Launcher_8"])

        handlers = self.logger.handlers[:]
        for handler in handlers:
            handler.close()
            self.logger.removeHandler(handler)
        sys.exit(result[0])

    def Setlogger(self):
        # setting up logger
        logger = logging.getLogger()
        logger.setLevel(logging.DEBUG)
        fileFormatter = logging.Formatter('%(asctime)s|%(levelname)s|%(message)s')
        streamFormatter = logging.Formatter('- %(levelname)s | %(message)s')

        # setting up file log
        file_handler = logging.handlers.RotatingFileHandler(self.params['logPath'], 'w')
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(fileFormatter)
        logger.addHandler(file_handler)

        # setting up prompt log
        stream_handler = logging.StreamHandler()
        if self.args['verbose']:
            stream_handler.setLevel(logging.DEBUG)
            logger.debug(self.trad["Launcher_9"])
        else:
            stream_handler.setLevel(logging.INFO)
        stream_handler.setFormatter(streamFormatter)
        logger.addHandler(stream_handler)
        return logger

    def DisplayInfos(self):
        # displaying installer content, used in debug context
        self.application.DisplayInfos()
        for ws in self.webServiceDict.values():
            ws.DisplayInfos()
        for schema in self.schemaDict.values():
            schema.DisplayInfos()
        if self.vas is not None:
            self.vas.DisplayInfos()
        return [0, ""]

    def RunCommand(self, command, verifyError=True):
        """
        RunCommand:
        used to tun command as we were in a command console, you must use absolutes path for all arguments

        usage
        command = 'httpd -M'.split()
        for line in RunCommand(command):
        print(line)
        """
        self.logger.debug(self.trad["Launcher_10"].format(command))
        p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        (output, err) = p.communicate()
        message = ""
        self.logger.debug(self.trad["Launcher_11"].format(str(output)))
        self.logger.debug(self.trad["Launcher_12"].format(str(err)))
        if verifyError:
            if str(err).lstrip('b\'').split('\\n')[0] != '' and str(err).lstrip('b\'').find("AH00558") == -1:
                return [1, str(err), inspect.stack()[0]]
            else:
                message = str(output).lstrip('b\'')
        else:
            if str(output).lstrip('b\'') != '':
                message = str(output).lstrip('b\'')
            else:
                message = str(err).lstrip('b\'')

        return [0, message.split('\\n')]

    def CheckDirectoryPath(self):
        if self.info['nature'] == 'app':
            if not os.path.isfile(self.params['appDirectory'] + "/conf/properties.json"):
                return [1, self.trad["Launcher_13"], inspect.stack()[0]]
        if self.params['installDep']:
            if not os.path.isfile(self.params['vasDirectory'] + "/rest/conf/properties_server.inc"):
                return [1, self.trad["Launcher_14"], inspect.stack()[0]]
        return [0, ""]

    def UpdateConfFolder(self, ws):
        if ws == 'vas':
            propertiesRessourcePath = os.path.join(self.params['ressourcesPath'], 'vas', 'core', 'rest', 'conf')
            propertiesVasPath = os.path.join(self.params['vasDirectory'], 'rest', 'conf')
        else:
            propertiesRessourcePath = os.path.join(self.params['ressourcesPath'], 'vas', 'web_services', ws, 'conf')
            propertiesVasPath = os.path.join(self.params['vasDirectory'], 'rest', 'conf', ws)

        # Mise à jour du dossier conf
        for file in os.listdir(propertiesRessourcePath):
            propertiesSrcPath = os.path.join(propertiesRessourcePath, file)
            propertiesDestPath = os.path.join(propertiesVasPath, file)
            if file.startswith("properties"):
                if not os.path.isfile(propertiesDestPath):
                    result = self.fileManipulator.CopyFile(propertiesSrcPath, propertiesDestPath)
                    if result[0] != 0:
                        return result
                else:
                    self.UpdateProperties(propertiesSrcPath, propertiesDestPath)
            else:
                # Ecrasement des fichiers qui ne sont pas des properties
                self.fileManipulator
                result = self.fileManipulator.RecursiveOverwriteCopy(propertiesSrcPath, propertiesDestPath)
                if result[0] != 0:
                    return result

    def UpdateProperties(self, propertiesSrcPath, propertiesDestPath):
        propertiesSrcList = self.ParseProperties(propertiesSrcPath)
        propertiesDestList = self.ParseProperties(propertiesDestPath)

        propertiesToAdd = []
        for propertiesName, propertiesValue in propertiesSrcList.items():
            if propertiesName not in propertiesDestList:
                propertiesToAdd.append((propertiesName, propertiesValue))
        if propertiesToAdd:
            self.fileManipulator.AppendToPropertiesFile(propertiesDestPath, propertiesToAdd)

    def ParseProperties(self, propertiesPath):
        with open(propertiesPath) as f:
            lines = f.readlines()
        regex = r"(^\$properties\[['\"].*['\"]]) ?= ?(.*)"

        propertiesList = {}
        for line in lines:
            line = line.strip()
            matches = re.finditer(regex, line, re.MULTILINE)
            for matchNum, match in enumerate(matches):
                propertiesList[str(match.group(1)).replace('"', "'")] = match.group(2)

        return propertiesList

    def GetProperties(self):
        if self.info['nature'] == 'app':
            propertiesFile = open(os.path.join(self.params['appDirectory'], "conf", "properties.json"), 'r', encoding="utf-8")
            propertiesFileStr = propertiesFile.read()
            propertiesFile.close()
            propertiesFileData = json.loads(propertiesFileStr)
            if propertiesFileData['environment'] != "":
                self.apache['environmentAlias'] = '_' + propertiesFileData['environment']
                self.apache['environment'] = propertiesFileData['environment']
        if self.params['installDep']:
            propertiesFile = open(os.path.join(self.params['vasDirectory'], "rest", "conf", "properties_server.inc"), 'r', encoding="utf-8")
            propertiesFileStr = propertiesFile.read()
            propertiesFile.close()
            for properties in propertiesFileStr.split('\n'):
                properties = properties.strip().split("=")
                if properties[0].startswith("$properties"):
                    if "'server'" in properties[0]:
                        self.postgres['dbHost'] = properties[1].strip("' ;")
                    if "'database'" in properties[0]:
                        self.postgres['dbName'] = properties[1].strip("' ;")
                    if "'port'" in properties[0]:
                        self.postgres['dbPort'] = properties[1].strip("' ;")
        return [0, ""]

    def PreLaunch(self):
        self.objectCheckList.append(self.info['nature'] + str(self.info['name']))
        try:
            if self.info['nature'] != 'schema':
                result = self.RequisitesChecking()
                if result[0] != 0:
                    return result
                result = self.GetApacheService()
                if result[0] != 0:
                    return result
                result = self.CheckApachePort()
                if result[0] != 0:
                    return result
                # Apache Service need to be stopped during all the process
                result = self.StopApacheService()
                if result[0] != 0:
                    return result
            result = self.LoadConfigurationFile()
            if result[0] != 0:
                return result
        except (BaseException) as err:
            return [1, str(err), inspect.stack()[0]]
        return [0, ""]

    def RequisitesChecking(self):
        self.logger.info(self.trad["Launcher_15"])

        # check if launched as administrator
        if platform.system() == 'Windows':
            if ctypes.windll.shell32.IsUserAnAdmin() == 0:
                self.logger.error(self.trad["Launcher_16"])
                return [1, self.trad["Launcher_17"], inspect.stack()[0]]
        else:
            if os.geteuid() != 0:
                self.logger.error(self.trad["Launcher_18"])
                return [1, self.trad["Launcher_19"], inspect.stack()[0]]

        result = self.CheckPostgresUser()
        if result[0] != 0:
            return result
        # restarting apache process to for him to consider changes
        result = self.RestartApacheService()
        if result[0] != 0:
            return result

        # Vérification que le port Apache est bien ouvert
        requests.get(self.apache['checkUrl'], verify=False)

        return [0, ""]

    def LoadConfigurationFile(self):
        # Loading all module found in ./dependencies, puttin dem in da list ov loaded dependence module
        listLoadedDepModule = {}
        if os.path.isdir(self.params['dependencies']):
            listDependenciesModule = os.listdir(self.params['dependencies'])
            self.logger.debug(listDependenciesModule)
            for mod in listDependenciesModule:
                if "dep" in mod:
                    try:
                        modKey = mod.split("_")[1]
                        modKey = modKey.split(".")[0]
                        listLoadedDepModule[modKey] = __import__("ressources.dependencies.%s" % mod[:-3], fromlist=["dependencies"])
                        self.logger.debug(modKey)
                    except ImportError as err:
                        self.logger.error(self.trad["Launcher_20"] + " " + str(err))
                        return [1, self.trad["Launcher_21"] + " " + str(err), inspect.stack()[0]]
            for mod in listLoadedDepModule.keys():
                self.logger.debug(mod)

        # path xml file
        self.logger.debug(self.trad["Launcher_22"].format(self.params['confFile']))

        file = open(self.params['confFile'], 'r')
        result = file.readlines()
        try:
            dInstallConf = xmldict.xml_to_dict(''.join(result).replace('\n', '').replace('\r', ''))['installer']
        except (BaseException) as err:
            self.logger.error(self.trad["Launcher_23"].format(str(err)))
            return [3, str(err), inspect.stack()[0]]

        # Transformation des non-listes en liste, exemple quand un objet a une seule dépendance celle-ci n'est pas en forme de liste
        if 'schemasCollection' in dInstallConf:
            if type(dInstallConf['schemasCollection']['schemas']).__name__ != 'list':
                tmp = dInstallConf['schemasCollection']['schemas']
                dInstallConf['schemasCollection']['schemas'] = []
                dInstallConf['schemasCollection']['schemas'].append(tmp)
            for schema in dInstallConf['schemasCollection']['schemas']:
                if 'dependenciesCollection' in schema:
                    if type(schema['dependenciesCollection']['dependency']).__name__ != 'list':
                        tmp = schema['dependenciesCollection']['dependency']
                        schema['dependenciesCollection']['dependency'] = []
                        schema['dependenciesCollection']['dependency'].append(tmp)

        if 'web_servicesCollection' in dInstallConf:
            if type(dInstallConf['web_servicesCollection']['web_services']).__name__ != 'list':
                tmp = dInstallConf['web_servicesCollection']['web_services']
                dInstallConf['web_servicesCollection']['web_services'] = []
                dInstallConf['web_servicesCollection']['web_services'].append(tmp)
            for ws in dInstallConf['web_servicesCollection']['web_services']:
                if 'dependenciesCollection' in ws:
                    if type(ws['dependenciesCollection']['dependency']).__name__ != 'list':
                        tmp = ws['dependenciesCollection']['dependency']
                        ws['dependenciesCollection']['dependency'] = []
                        ws['dependenciesCollection']['dependency'].append(tmp)

        if 'application' in dInstallConf:
            if 'dependenciesCollection' in dInstallConf['application']:
                if type(dInstallConf['application']['dependenciesCollection']['dependency']).__name__ != 'list':
                    tmp = dInstallConf['application']['dependenciesCollection']['dependency']
                    dInstallConf['application']['dependenciesCollection']['dependency'] = []
                    dInstallConf['application']['dependenciesCollection']['dependency'].append(tmp)

        if 'vas' in dInstallConf:
            if 'dependenciesCollection' in dInstallConf['vas']:
                if type(dInstallConf['vas']['dependenciesCollection']['dependency']).__name__ != 'list':
                    tmp = dInstallConf['vas']['dependenciesCollection']['dependency']
                    dInstallConf['vas']['dependenciesCollection']['dependency'] = []
                    dInstallConf['vas']['dependenciesCollection']['dependency'].append(tmp)

        self.logger.info(self.trad["Launcher_24"])

        ########################
        # Application retrieval#
        applicationInConfFile = dInstallConf['application']
        self.logger.debug(self.trad["Launcher_25"])
        dependenceList = []
        self.logger.debug(self.trad["Launcher_26"].format(applicationInConfFile['name']))
        # generating dependence list
        if 'dependenciesCollection' in applicationInConfFile:
            for dependenceInConfFile in applicationInConfFile['dependenciesCollection']['dependency']:
                module = None
                if dependenceInConfFile['nature'].startswith("extern"):
                    try:
                        module = listLoadedDepModule[dependenceInConfFile['name']]
                    except KeyError:
                        self.logger.error(self.trad["Launcher_27"].format(dependenceInConfFile['name']))
                        return [1, self.trad["Launcher_28"].format(dependenceInConfFile['name']), inspect.stack()[0]]
                if 'name' not in dependenceInConfFile:
                    dependenceInConfFile['name'] = ''
                dependenceList.append(Dependence(self, dependenceInConfFile, module))
        # if it's vitis, create a vitis instance otherwise create an instance of Application
        self.application = Application(self, applicationInConfFile['name'], applicationInConfFile['version'], dependenceList)

        #######################
        # Webservice retrieval#
        self.logger.debug(self.trad["Launcher_29"])
        if 'web_servicesCollection' in dInstallConf:
            for webServiceInConfFile in dInstallConf['web_servicesCollection']['web_services']:
                dependenceList = []
                self.logger.debug(self.trad["Launcher_30"].format(webServiceInConfFile['name']))
                # generating dependence list
                if 'dependenciesCollection' in webServiceInConfFile:
                    for dependenceInConfFile in webServiceInConfFile['dependenciesCollection']['dependency']:
                        module = None
                        if dependenceInConfFile['nature'].startswith("extern"):
                            try:
                                module = listLoadedDepModule[dependenceInConfFile['name']]
                            except KeyError:
                                self.logger.error(self.trad["Launcher_31"].format(dependenceInConfFile['name']))
                                return [1, self.trad["Launcher_32"].format(dependenceInConfFile['name']), inspect.stack()[0]]
                        if 'name' not in dependenceInConfFile:
                            dependenceInConfFile['name'] = ''
                        if 'version' not in dependenceInConfFile:
                            dependenceInConfFile['version'] = ''
                        dependenceList.append(Dependence(self, dependenceInConfFile, module))
                self.webServiceDict[webServiceInConfFile['name']] = WebService(self, webServiceInConfFile['name'], webServiceInConfFile['version'], dependenceList)

        ################
        # vas retrieval#
        if 'vas' in dInstallConf:
            vasInConfFile = dInstallConf['vas']
            self.logger.debug(self.trad["Launcher_33"])
            dependenceList = []
            # generating dependence list
            if 'dependenciesCollection' in vasInConfFile:
                for dependenceInConfFile in vasInConfFile['dependenciesCollection']['dependency']:
                    module = None
                    if dependenceInConfFile['nature'].startswith("extern"):
                        try:
                            module = listLoadedDepModule[dependenceInConfFile['name']]
                        except KeyError:
                            self.logger.error(self.trad["Launcher_34"].format(dependenceInConfFile['name']))
                            return [1, self.trad["Launcher_35"].format(dependenceInConfFile['name']), inspect.stack()[0]]
                    if 'name' not in dependenceInConfFile:
                        dependenceInConfFile['name'] = ''
                    if 'version' not in dependenceInConfFile:
                        dependenceInConfFile['version'] = ''
                    dependenceList.append(Dependence(self, dependenceInConfFile, module))
            self.vas = Vas(self, vasInConfFile['version'], dependenceList)

        ###################
        # schema retrieval#
        schemaDictInConfFile = dInstallConf['schemasCollection']
        self.logger.debug(self.trad["Launcher_36"])
        if 'schemasCollection' in dInstallConf:
            for schemaInConfFile in schemaDictInConfFile['schemas']:
                dependenceList = []
                # generating dependence list
                if 'dependenciesCollection' in schemaInConfFile:
                    for dependenceInConfFile in schemaInConfFile['dependenciesCollection']['dependency']:
                        module = None
                        if dependenceInConfFile['nature'].startswith("extern"):
                            try:
                                module = listLoadedDepModule[dependenceInConfFile['name']]
                            except KeyError:
                                self.logger.error(self.trad["Launcher_37"].format(dependenceInConfFile['name']))
                                return [1, self.trad["Launcher_38"].format(dependenceInConfFile['name']), inspect.stack()[0]]
                        dependenceList.append(Dependence(self, dependenceInConfFile, module))
                self.schemaDict[schemaInConfFile['name']] = Schema(self, schemaInConfFile['name'], schemaInConfFile['version'], schemaInConfFile['object'], dependenceList)

        result = self.DisplayInfos()
        if result[0] != 0:
            return result

        return [0, ""]

    def CheckFreeSpace(self):
        if 'vasDirectory' in self.params:
            if os.path.isdir(self.params['vasDirectory']):
                directoryVas = self.params['vasDirectory']
            elif os.path.isdir(os.path.dirname(self.params['vasDirectory'])):
                directoryVas = os.path.dirname(self.params['vasDirectory'])
            else:
                directoryVas = os.path.dirname(os.path.dirname(self.params['vasDirectory']))
            freeSpace = 0
            try:
                freeSpace = shutil.disk_usage(directoryVas).free / 1024**3
            except Exception as err:
                self.logger.error(self.params['vasDirectory'] + ': ' + str(err))
                return [1, self.params['vasDirectory'] + ': ' + str(err), inspect.stack()[0]]
            if freeSpace < 2:
                return [1, self.trad["Launcher_39"]]

        if 'appDirectory' in self.params:
            if os.path.isdir(self.params['appDirectory']):
                directoryApp = self.params['appDirectory']
            elif os.path.isdir(os.path.dirname(self.params['appDirectory'])):
                directoryApp = os.path.dirname(self.params['appDirectory'])
            else:
                directoryApp = os.path.dirname(os.path.dirname(self.params['vasDirectory']))
            try:
                freeSpace = shutil.disk_usage(directoryApp).free / 1024**3
            except Exception as err:
                self.logger.error(self.params['appDirectory'] + ': ' + str(err))
                return [1, self.params['appDirectory'] + ': ' + str(err), inspect.stack()[0]]
            if freeSpace < 2:
                return [1, self.trad["Launcher_40"]]

        return [0, ""]
