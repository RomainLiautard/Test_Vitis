# coding: utf-8
import inspect
import requests


class Dependence(object):
	"""
	Class Dependence description:
		Define a application by his name, version, dependence, installation directory,
		url of main Vitis Application Server and apache service it going to use to be accessed
		Attributes:
			name
			version
			nature
			depModulelaunchParameters

		operations:
			DisplayInfos()
			Check()
			CheckWs()
			CheckVas()
			CheckExtern()
	"""
	def __init__(self, Tools, dependenceInConfFile, depModule=None):
		self.name = dependenceInConfFile['name']
		self.Tools = Tools
		self.version = dependenceInConfFile['version']
		self.nature = dependenceInConfFile['nature']
		self.depParams = {}
		for key, value in dependenceInConfFile.items():
			self.depParams[key] = value
		self.depModule = depModule

	def DisplayInfos(self):
		self.Tools.logger.debug(self.Tools.trad["Dependence_1"].format(self.name))
		self.Tools.logger.debug(self.Tools.trad["Dependence_2"].format(self.version))
		self.Tools.logger.debug(self.Tools.trad["Dependence_3"].format(self.nature))
		if self.depModule is not None:
			self.Tools.logger.debug(self.depModule.DisplayInfos(self))
		return [0, ""]

	def Check(self):
		action = {"web_services": self.__CheckWs, "vas": self.__CheckVas, "schema": self.__CheckSchema}
		try:
			result = action[self.nature]()
			if result[0] == 0:
				version = result[1]
			else:
				return result
		except BaseException as err:
			self.Tools.logger.error(self.Tools.trad["Dependence_4"].format(self.name))
			return [1, err, inspect.stack()[0]]
		return [0, version]

	def __CheckWs(self):
		self.Tools.logger.info(self.Tools.trad["Dependence_5"].format(self.name))
		try:
			result = self.Tools.StartApacheService()
			if result[0] != 0:
				return result
			r = requests.get(self.Tools.apache['checkUrl'] + "/rest" + self.Tools.apache['environmentAlias'] + "/" + self.name + "/versions", verify=False)
			version = r.json()['version']
			result = self.Tools.StopApacheService()
			if result[0] != 0:
				return result
		except Exception:
			return [0, '']
		return [0, version]

	def __CheckVas(self):
		self.Tools.logger.info(self.Tools.trad["Dependence_6"])
		try:
			result = self.Tools.StartApacheService()
			if result[0] != 0:
				return result
			r = requests.get(self.Tools.apache['checkUrl'] + "/rest" + self.Tools.apache['environmentAlias'] + "/vitis/versions", verify=False)
			version = r.json()['version']
			result = self.Tools.StopApacheService()
			if result[0] != 0:
				return result
		except Exception:
			return [0, '']
		return [0, version]

	def __CheckSchema(self):
		result = self.Tools.GetVersionSchema(self.name)
		if result[0] == 0:
			sVersion = result[1]
		else:
			return result
		return [0, sVersion]

	def CheckExtern(self, mode):
		return self.depModule.Check(self, mode)
