"""Classe permettant des actions sur Apache"""
# coding: utf-8
import inspect
import time
import subprocess
import glob
import platform
import os
if platform.system() == 'Windows':
    import wmi


class ApacheTools(object):
    """Classe permettant des actions sur Apache"""

    def __init__(self):
        self.apache = {}
        self.apache['name'] = self.args['apacheService']
        self.apache['port'] = self.args['apacheServicePort']
        self.apache['environmentAlias'] = self.args['environmentAlias']
        if 'checkUrl' in self.args:
            self.apache['checkUrl'] = self.args['checkUrl']
        if 'vasUrl' in self.args:
            self.apache['vasUrl'] = self.args['vasUrl']
        self.apache['confPath'] = ''
        self.apache['exePath'] = ''
        self.apache['dirPath'] = ''

    def GetApacheState(self):  # Not in use (maybe)
        """Récupération du status d'Apache"""
        if platform.system() == 'Windows':
            result = wmi.WMI().Win32_Service(Name=self.apache['name'])[0].State
        else:
            result = self.RunCommand(["service", self.apache['name'], "status"])
            if result[0] != 0:
                return result
        return [0, result]

    def RestopApacheService(self):
        """ Permet de démarer et d'arrêter Apache pour voir s'il y a des erreurs"""
        result = self.StartApacheService()
        if result[0] != 0:
            return result
        result = self.StopApacheService()
        if result[0] != 0:
            return result
        return [0, ""]

    def RestartApacheService(self):
        """Permet de redémarer le service Apache"""
        result = self.StopApacheService()
        if result[0] != 0:
            return result
        result = self.StartApacheService()
        if result[0] != 0:
            return result
        return [0, ""]

    def StopApacheService(self):
        """Permet d'arrêter le service Apache"""
        if platform.system() == 'Windows':
            c = wmi.WMI()
            for service in c.Win32_Service(Name=self.apache['name']):
                self.logger.debug(service)
                if service.Started:
                    self.logger.debug(self.trad["ApacheTools_1"].format(self.apache['name']))
                    self.logger.debug(service.StopService())
                    bStopped = False
                    while not bStopped:
                        for service in c.Win32_Service(Name=self.apache['name']):
                            if service.State == "Stopped":
                                bStopped = True
                            else:
                                time.sleep(1)
                else:
                    self.logger.debug(self.trad["ApacheTools_2"])
        else:
            result = subprocess.check_call(["service", self.apache['name'], "stop"])
            if result != 0:
                return [1, result, inspect.stack()[0]]

        return [0, ""]

    def StartApacheService(self):
        """ Permet de démarer le service Apache"""
        if platform.system() == 'Windows':
            c = wmi.WMI()
            for service in c.Win32_Service(Name=self.apache['name']):
                self.logger.debug(service)
                if not service.Started:
                    self.logger.debug(self.trad["ApacheTools_3"].format(self.apache['name']))
                    self.logger.debug(service.StartService())
                    bStarted = False
                    while not bStarted:
                        for service in c.Win32_Service(Name=self.apache['name']):
                            if service.State == "Running":
                                bStarted = True
                            elif service.State == 'Stopped':
                                return [1, self.trad["ApacheTools_6"], inspect.stack()[0]]
                            else:
                                time.sleep(1)
        else:
            result = subprocess.check_call(["service", self.apache['name'], "start"])
            if result != 0:
                return [1, result, inspect.stack()[0]]
        return [0, ""]

    def GetApacheService(self):
        """
        GetApacheService:
            return apache path from apache service given name
        """
        if platform.system() == 'Windows':
            c = wmi.WMI()
            for process in c.Win32_Service(Name=self.apache['name']):
                httpd_exePath = process.PathName.split('"')[1]
        else:
            httpd_exePath = self.apache['name'] + 'ctl'

        if platform.system() != 'Windows' or os.path.isfile(httpd_exePath):
            if platform.system() == 'Windows':
                self.apache['dirPath'] = os.path.dirname(os.path.dirname(httpd_exePath))

            result = self.RunCommand([httpd_exePath, "-V"])
            if result[0] == 0:
                lines = result[1]
            else:
                return result

            for line in lines:
                line = line.rstrip('\\r')
                if platform.system() != 'Windows' and "HTTPD_ROOT" in line:
                    self.apache['dirPath'] = line.split("=")[1].strip('"')

                if "SERVER_CONFIG_FILE" in line:
                    self.apache['confPath'] = line.split("=")[1].strip('"')
                    self.apache['exePath'] = httpd_exePath

            self.apache['confPath'] = os.path.join(self.apache['dirPath'], self.apache['confPath'])

            if 'confPath' not in self.apache:
                return [1, self.trad["ApacheTools_7"], inspect.stack()[0]]
            elif not os.path.isfile(self.apache['confPath']):
                return [1, self.trad["ApacheTools_8"].format(self.apache['confPath']), inspect.stack()[0]]
        else:
            return [1, self.trad["ApacheTools_9"].format(self.apache['name']), inspect.stack()[0]]
        return [0, ""]

    def GetApacheAliasFile(self, confFile, aliasList):
        listFile = []
        if os.path.isfile(confFile):
            listFile.append(confFile)
        else:
            for file in glob.glob(confFile):
                if os.path.isfile(file):
                    listFile.append(file)
        for confFile in listFile:
            result = self.GetApacheAlias(confFile, aliasList)
            if result[0] == 0:
                aliasList = result[1]
            else:
                return result
        return [0, aliasList]

    def GetApacheAlias(self, confFile, aliasList):
        f = open(confFile, 'r')
        for line in f:
            tmpLine = line.strip()
            if not tmpLine.startswith('#'):
                if tmpLine.startswith('Alias') or tmpLine.startswith('ScriptAlias'):
                    test = tmpLine.split(" ")
                    aliasList.append(test[1].strip('/'))
                elif tmpLine.startswith('Include'):
                    confFile = tmpLine.split(" ")[1]
                    if not os.path.isfile(confFile) and not os.path.isdir(os.path.dirname(confFile)):
                        confFile = self.apache['dirPath'] + "/" + confFile

                    result = self.GetApacheAliasFile(confFile, aliasList)
                    if result[0] != 0:
                        return result
        f.close()
        return [0, aliasList]

    def CleanApacheAlias(self, apacheAlias):
        lApacheAlias = []
        for alias in apacheAlias:
            tmp = alias.replace('[ENV]', self.apache['environmentAlias'])
            tmp = tmp.replace('[APP]', self.application.name)
            lApacheAlias.append(tmp)

        return [0, lApacheAlias]

    def CheckApacheModule(self, serviceNat, serviceName=None):
        self.logger.debug(self.trad["ApacheTools_4"])
        result = self.RunCommand([self.apache['exePath'], "-M"])
        if result[0] == 0:
            lines = result[1]
        else:
            return result

        modulesActivated = []
        for line in lines:
            line = line.rstrip('\\r')
            modulesActivated.append(line)

        if serviceNat == 'app':
            src = os.path.join(self.params['ressourcesPath'], 'app', 'complement', 'listModuleApache.txt')
        else:
            src = os.path.join(self.params['ressourcesPath'], 'vas', 'complement', serviceName if serviceName is not None else serviceNat, 'listModuleApache.txt')

        if os.path.isfile(src):
            with open(src, 'r', encoding="utf-8") as moduleFile:
                modules = moduleFile.read()

            for moduleNeeded in modules.split('\n'):
                missingModule = True
                for module in modulesActivated:
                    if moduleNeeded in module:
                        missingModule = False
                        break
                if missingModule:
                    self.logger.debug(self.trad["ApacheTools_5"].format(moduleNeeded))
                    if moduleNeeded == 'ssl_module':
                        return [1, self.trad["ApacheTools_10"].format(moduleNeeded), inspect.stack()[0]]
                    else:
                        result = self.fileManipulator.EnableApacheModule(moduleNeeded)
                        if result[0] != 0:
                            return result
        return [0, ""]

    def DoesAliasExist(self, apacheConfPath):
        aliasInstalled = []
        result = self.GetApacheAliasFile(self.apache['confPath'], [])
        if result[0] == 0:
            aliasInstalled = result[1]
        else:
            return result

        result = self.GetApacheAlias(apacheConfPath, [])
        if result[0] == 0:
            apacheAlias = result[1]
        else:
            return result
        result = self.CleanApacheAlias(apacheAlias)
        if result[0] == 0:
            apacheAlias = result[1]
        else:
            return result

        for alias in apacheAlias:
            if alias in aliasInstalled:
                return [0, alias]
        return [0, '']

    def CheckApachePort(self):
        result = self.GetApachePort(self.apache['confPath'], [])
        if result[0] == 0:
            portList = result[1]
        else:
            return result
        if ':' in self.apache['checkUrl']:
            portSsl = self.apache['checkUrl'].split(":")[2]
        else:
            portSsl = '443'
        if portSsl not in portList:
            return [1, self.trad["dep_apache_4"].format(portSsl)]

        return [0, '']

    def GetApachePortFile(self, confFile, portList):
        listFile = []
        if os.path.isfile(confFile):
            listFile.append(confFile)
        else:
            for file in glob.glob(confFile):
                if os.path.isfile(file):
                    listFile.append(file)
        for confFile in listFile:
            result = self.GetApachePort(confFile, portList)
            if result[0] == 0:
                portList = result[1]
            else:
                return result
        return [0, portList]

    def GetApachePort(self, confFile, portList):
        f = open(confFile, 'r')
        for line in f:
            tmpLine = line.strip()
            if not tmpLine.startswith('#'):
                if tmpLine.startswith('Listen'):
                    test = tmpLine.split(" ")[1]
                    if ":" in test:
                        tmp = test.split(":")[1]
                    else:
                        tmp = test
                    portList.append(tmp)
                elif tmpLine.startswith('Include'):
                    confFile = tmpLine.split(" ")[1]
                    if not os.path.isfile(confFile) and not os.path.isdir(os.path.dirname(confFile)):
                        confFile = self.apache['dirPath'] + "/" + confFile

                    result = self.GetApachePortFile(confFile, portList)
                    if result[0] != 0:
                        return result
        f.close()
        return [0, portList]
