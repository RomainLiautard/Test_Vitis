# coding: utf-8
import datetime
import inspect
import os
import platform
import xmldict


class Report(object):
	"""docstring for SetupReport"""
	def __init__(self, Tools):
		self.Tools = Tools
		self.content = self.Tools.reportDict

	def CreateReport(self):
		self.BuildingReport()
		self.WritingReport()

	def BuildingReport(self):
		self.content['setupDate'] = datetime.datetime.today().strftime("The %Y-%m-%d at %H:%M")

		file = open(os.path.join(self.Tools.params['ressourcesPath'], "installConf.xml"), 'r', encoding="utf-8")
		result = file.readlines()
		try:
			dInstallConf = xmldict.xml_to_dict(''.join(result).replace('\n', '').replace('\r', ''))['installer']
		except (BaseException) as err:
			self.Tools.logger.error(self.Tools.trad["Report_1"].format(str(err)))
			return [1, str(err), inspect.stack()[0]]

		# Transformation des non-listes en liste, exemple quand un objet a une seule dépendance celle-ci n'est pas en forme de liste
		if 'schemaCollection' in dInstallConf:
			if type(dInstallConf['schemaCollection']['schema']).__name__ != 'list':
				tmp = dInstallConf['schemaCollection']['schema']
				dInstallConf['schemaCollection']['schema'] = []
				dInstallConf['schemaCollection']['schema'].append(tmp)
			for schema in dInstallConf['schemaCollection']['schema']:
				if 'dependenciesCollection' in schema:
					if type(schema['dependenciesCollection']['dependency']).__name__ != 'list':
						tmp = schema['dependenciesCollection']['dependency']
						schema['dependenciesCollection']['dependency'] = []
						schema['dependenciesCollection']['dependency'].append(tmp)

		if 'web_servicesCollection' in dInstallConf:
			if type(dInstallConf['web_servicesCollection']['web_services']).__name__ != 'list':
				tmp = dInstallConf['web_servicesCollection']['web_services']
				dInstallConf['web_servicesCollection']['web_services'] = []
				dInstallConf['web_servicesCollection']['web_services'].append(tmp)
			for ws in dInstallConf['web_servicesCollection']['web_services']:
				if 'dependenciesCollection' in ws:
					if type(ws['dependenciesCollection']['dependency']).__name__ != 'list':
						tmp = ws['dependenciesCollection']['dependency']
						ws['dependenciesCollection']['dependency'] = []
						ws['dependenciesCollection']['dependency'].append(tmp)

		if 'application' in dInstallConf:
			if 'dependenciesCollection' in dInstallConf['application']:
				if type(dInstallConf['application']['dependenciesCollection']['dependency']).__name__ != 'list':
					tmp = dInstallConf['application']['dependenciesCollection']['dependency']
					dInstallConf['application']['dependenciesCollection']['dependency'] = []
					dInstallConf['application']['dependenciesCollection']['dependency'].append(tmp)

		if 'vas' in dInstallConf:
			if 'dependenciesCollection' in dInstallConf['vas']:
				if type(dInstallConf['vas']['dependenciesCollection']['dependency']).__name__ != 'list':
					tmp = dInstallConf['vas']['dependenciesCollection']['dependency']
					dInstallConf['vas']['dependenciesCollection']['dependency'] = []
					dInstallConf['vas']['dependenciesCollection']['dependency'].append(tmp)

		if 'app' in self.content.keys():
			self.content['app']['version'] = dInstallConf["application"]["version"].strip()
			self.content['app']['location'] = self.Tools.params['appDirectory']
			self.content['app']['url'] = self.Tools.apache['vasUrl'] + '/' + dInstallConf["application"]["name"].strip() + self.Tools.apache['environmentAlias']
			self.content['app']['login'] = str(self.Tools.params['adminLogin']) + "/" + str(self.Tools.params['adminPswd'])
			self.content['app']['name'] = dInstallConf["application"]["name"].strip()

		if 'vas' in self.content.keys():
			self.content['vas']['location'] = self.Tools.params['vasDirectory']
			self.content['vas']['version'] = dInstallConf["vas"]["version"].strip()
			self.content['vas']['url'] = self.Tools.apache['vasUrl'] + '/rest' + self.Tools.apache['environmentAlias']

		if 'web_services' in self.content.keys():
			for i in range(len(self.content['web_services'])):
				for webService in dInstallConf["web_servicesCollection"]['web_services']:
					if self.content['web_services'][i]['name'] == webService['name']:
						self.content['web_services'][i]['version'] = webService['version'].strip()
						break

		if 'schema' in self.content.keys():
			for i in range(len(self.content['schema'])):
				for schema in dInstallConf["schemasCollection"]['schemas']:
					if self.content['schema'][i]['name'] == schema['name']:
						self.content['schema'][i]['version'] = schema['version'].strip()
						break

		if 'vasDirectory' in self.Tools.params and self.Tools.params['vasDirectory'] is not None:
			# Vérification de la version de php
			if platform.system() == 'Windows':
				phpPath = os.path.join(self.Tools.params['vasDirectory'], "server", "php", "php.exe")
			else:
				phpPath = os.path.join(self.Tools.params['vasDirectory'], "server", "php", "bin", "php")
			if os.path.isfile(phpPath):
				result = self.Tools.RunCommand([phpPath, '-v'])
				self.content['php'] = {}
				if result[0] == 0:
					line = result[1][0]
					self.content['php']['version'] = line.strip(' \\r')
				else:
					self.content['php']['version'] = self.Tools.trad["Report_2"]
					self.content['php']['messageError'] = result[1]
				self.content['php']['location'] = os.path.dirname(phpPath)

			# Vérification de la version de mapserver
			if platform.system() == 'Windows':
				mapServerPath = os.path.join(self.Tools.params['vasDirectory'], "server", "mapserver", "mapserv.exe")
			else:
				mapServerPath = "/var/www/vmap/vas/server/mapserver/bin/mapserv"
			if os.path.isfile(mapServerPath):
				result = self.Tools.RunCommand([mapServerPath, '-v'])
				self.content['mapserver'] = {}
				if result[0] == 0:
					line = result[1][0]
					self.content['mapserver']['version'] = line.strip(' \\r')
				else:
					self.content['mapserver']['version'] = self.Tools.trad["Report_2"]
					self.content['mapserver']['messageError'] = result[1]
				self.content['mapserver']['location'] = os.path.dirname(mapServerPath)

			# Vérification de la version de FOP
			if platform.system() == 'Windows':
				fopPath = os.path.join(self.Tools.params['vasDirectory'], "server", "fop", "fop.bat")
			else:
				fopPath = os.path.join(self.Tools.params['vasDirectory'], "server", "fop", "fop")
			if os.path.isfile(fopPath):
				result = self.Tools.RunCommand([fopPath, '-v'])
				self.content['fop'] = {}
				if result[0] == 0:
					line = result[1][0]
					self.content['fop']['version'] = line.strip(' \\r')
				else:
					self.content['fop']['version'] = self.Tools.trad["Report_3"]
					self.content['fop']['messageError'] = result[1]
				self.content['fop']['location'] = os.path.dirname(fopPath)

			# Vérification de la version de java
			if platform.system() == 'Windows':
				javaPath = os.path.join(self.Tools.params['vasDirectory'], "server", "jre", "bin", "java.exe")
			else:
				javaPath = os.path.join(self.Tools.params['vasDirectory'], "server", "jre", "bin", "java")
			if os.path.isfile(javaPath):
				result = self.Tools.RunCommand([javaPath, '-version'], False)
				self.content['java'] = {}
				if result[0] == 0:
					line = result[1][0]
					self.content['java']['version'] = line.strip(' \\r')
				else:
					self.content['java']['version'] = self.Tools.trad["Report_4"]
					self.content['java']['messageError'] = result[1]
				self.content['java']['location'] = os.path.dirname(os.path.dirname(javaPath))

			# Vérification de la version de phantomjs
			if platform.system() == 'Windows':
				phantomjsPath = os.path.join(self.Tools.params['vasDirectory'], "server", "phantomjs", "bin", "phantomjs.exe")
			else:
				phantomjsPath = os.path.join(self.Tools.params['vasDirectory'], "server", "phantomjs", "bin", "phantomjs")
			if os.path.isfile(phantomjsPath):
				result = self.Tools.RunCommand([phantomjsPath, '-v'])
				self.content['phantomjs'] = {}
				if result[0] == 0:
					line = result[1][0]
					self.content['phantomjs']['version'] = line.strip(' \\r')
				else:
					self.content['phantomjs']['version'] = self.Tools.trad["Report_5"]
					self.content['phantomjs']['messageError'] = result[1]
				self.content['phantomjs']['location'] = os.path.dirname(os.path.dirname(phantomjsPath))

	def WritingReport(self):
		reportFile = open(os.path.join(os.path.dirname(self.Tools.params['logPath']), "install_report_" + datetime.datetime.today().strftime("%d-%m-%Y_%H-%M") + ".txt"), 'w+', encoding="utf-8")
		reportFile.write(self.content['setupDate'] + "\n")
		reportFile.write("Installation Sheet\n")
		reportFile.write("\n")

		reportFile.write("Command Line:" + "\n")
		reportFile.write(self.content['commandLine'])
		reportFile.write("\n")

		bError = True
		for content in self.content.keys():
			if not content in('commandLine', 'messageError', 'setupDate'):
				bError = False
				break
		if bError:
			reportFile.write("\n")
			reportFile.write("Status: Aborted\n")
			reportFile.write("Error: " + self.content['messageError'] + "\n")

		if 'app' in self.content.keys():
			reportFile.write("\n")
			reportFile.write("Application " + self.content['app']['name'] + "\n")
			reportFile.write("\tVersion: " + self.content['app']['version'] + "\n")
			reportFile.write("\tLocation: " + self.content['app']['location'] + "\n")
			reportFile.write("\tURL: " + self.content['app']['url'] + "\n")
			reportFile.write("\tLogin: " + self.content['app']['login'] + "\n")
			reportFile.write("\tAction: " + self.content['app']['action'] + "\n")
			reportFile.write("\tStatus: " + self.content['app']['status'] + "\n")
			if self.content['app']['status'] == 'aborted':
				reportFile.write("\tErrorMessage: " + str(self.content['app']['errorMessage']) + "\n")

		if 'vas' in self.content.keys():
			reportFile.write("\n")
			reportFile.write("VAS" + "\n")
			reportFile.write("\tLocation: " + self.content['vas']['location'] + "\n")
			reportFile.write("\tVersion: " + self.content['vas']['version'] + "\n")
			reportFile.write("\tURL: " + self.content['vas']['url'] + "\n")
			reportFile.write("\tAction: " + self.content['vas']['action'] + "\n")
			reportFile.write("\tStatus: " + self.content['vas']['status'] + "\n")
			if self.content['vas']['status'] == 'aborted':
				reportFile.write("\tErrorMessage: " + str(self.content['vas']['errorMessage']) + "\n")

		if 'web_services' in self.content.keys():
			reportFile.write("\n")
			reportFile.write("Web Service" + "\n")
			for webService in self.content['web_services']:
				reportFile.write("\t" + webService["name"] + ":" + "\n")
				reportFile.write("\t\tVersion: " + webService["version"] + "\n")
				reportFile.write("\t\tAction: " + webService["action"] + "\n")
				reportFile.write("\t\tStatus: " + webService["status"] + "\n")
				if webService["status"] == 'aborted':
					reportFile.write("\tErrorMessage: " + str(webService['errorMessage']) + "\n")

		if 'schema' in self.content.keys():
			reportFile.write("\n")
			reportFile.write("Schema" + "\n")
			for schema in self.content['schema']:
				reportFile.write("\t" + schema["name"] + ":" + "\n")
				reportFile.write("\t\tVersion: " + schema["version"] + "\n")
				reportFile.write("\t\tAction: " + schema["action"] + "\n")
				reportFile.write("\t\tStatus: " + schema["status"] + "\n")
				if schema["status"] == 'aborted':
					reportFile.write("\tErrorMessage: " + str(schema['errorMessage']) + "\n")

		if 'php' in self.content.keys():
			reportFile.write("\n")
			reportFile.write("PHP" + "\n")
			reportFile.write("\tVersion: " + self.content['php']['version'] + "\n")
			if 'messageError' in self.content['php']:
				reportFile.write("\tError: " + str(self.content['php']['messageError']) + "\n")
			reportFile.write("\tLocation: " + self.content['php']['location'] + "\n")

		if 'mapserver' in self.content.keys():
			reportFile.write("\n")
			reportFile.write("MAPSERVER" + "\n")
			reportFile.write("\tVersion: " + self.content['mapserver']['version'] + "\n")
			if 'messageError' in self.content['mapserver']:
				reportFile.write("\tError: " + str(self.content['mapserver']['messageError']) + "\n")
			reportFile.write("\tLocation: " + self.content['mapserver']['location'] + "\n")

		if 'phantomjs' in self.content.keys():
			reportFile.write("\n")
			reportFile.write("PHANTOMJS" + "\n")
			reportFile.write("\tVersion: " + self.content['phantomjs']['version'] + "\n")
			if 'messageError' in self.content['phantomjs']:
				reportFile.write("\tError: " + str(self.content['phantomjs']['messageError']) + "\n")
			reportFile.write("\tLocation: " + self.content['phantomjs']['location'] + "\n")

		if 'fop' in self.content.keys():
			reportFile.write("\n")
			reportFile.write("FOP" + "\n")
			reportFile.write("\tVersion: " + self.content['fop']['version'] + "\n")
			if 'messageError' in self.content['fop']:
				reportFile.write("\tError: " + str(self.content['fop']['messageError']) + "\n")
			reportFile.write("\tLocation: " + self.content['fop']['location'] + "\n")

		if 'java' in self.content.keys():
			reportFile.write("\n")
			reportFile.write("JAVA" + "\n")
			reportFile.write("\tVersion: " + self.content['java']['version'] + "\n")
			if 'messageError' in self.content['java']:
				reportFile.write("\tError: " + str(self.content['java']['messageError']) + "\n")
			reportFile.write("\tLocation: " + self.content['java']['location'] + "\n")

		reportFile.close()
