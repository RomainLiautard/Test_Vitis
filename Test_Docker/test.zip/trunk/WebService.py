# coding: utf-8
import os
import inspect


class WebService(object):
	"""
	Class WebService description:
		Define a application by his name, version, dependence, installation directory,
		url of main Vitis Application Server and apache service it going to use to be accessed
		Attributes:
			name
			version
			dependsOn
			schemaUsed
			directory
			apacheName
			params

		operations:
			Install()
			DisplayInfos()
	"""
	def __init__(self, Tools, name, version, dependsOn):
		self.name = name
		self.Tools = Tools
		self.version = version
		self.dependsOn = dependsOn

	def Install(self):
		# checking if not already installed
		directoryPath = os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", self.name)
		if os.path.isdir(directoryPath):
			currentVersion = self.GetVersion().replace(".", "")
			version = self.version.replace(".", "")
			if currentVersion == '0':
				return [1, self.Tools.trad["WebService_1"].format(directoryPath), inspect.stack()[0]]
			elif version == currentVersion:
				return [1, self.Tools.trad["WebService_2"].format(directoryPath), inspect.stack()[0]]
			elif currentVersion < version:
				return [1, self.Tools.trad["WebService_3"].format(directoryPath), inspect.stack()[0]]
			else:
				return [1, self.Tools.trad["WebService_4"].format(directoryPath), inspect.stack()[0]]

		self.Tools.logger.info(self.Tools.trad["WebService_5"].format(self.name))
		# copy ressources/vas/web_services/"name"/ws  ---->  vasDir/rest/ws/"name"
		result = self.Tools.fileManipulator.RecursiveOverwriteCopy(os.path.join(self.Tools.params['ressourcesPath'], "vas", "web_services", self.name, "ws"), os.path.join(self.Tools.params['vasDirectory'], "rest", "ws", self.name))
		if result[0] != 0:
			return result
		# copy ressources/vas/web_services/"name"/ws_data  ---->  vasDir/ws_data
		result = self.Tools.fileManipulator.RecursiveOverwriteCopy(os.path.join(self.Tools.params['ressourcesPath'], "vas", "web_services", self.name, "ws_data"), os.path.join(self.Tools.params['vasDirectory'], "ws_data"))
		if result[0] != 0:
			return result
		# copy ressources/vas/web_services/"name"/public  ---->  vasDir/public/"name"
		result = self.Tools.fileManipulator.RecursiveOverwriteCopy(os.path.join(self.Tools.params['ressourcesPath'], "vas", "web_services", self.name, "public"), os.path.join(self.Tools.params['vasDirectory'], "public", self.name))
		if result[0] != 0:
			return result
		# copy ressources/vas/web_services/"name"/upload  ---->  vasDir/upload/"name"
		result = self.Tools.fileManipulator.RecursiveOverwriteCopy(os.path.join(self.Tools.params['ressourcesPath'], "vas", "web_services", self.name, "upload"), os.path.join(self.Tools.params['vasDirectory'], "upload", self.name))
		if result[0] != 0:
			return result
		# copy ressources/vas/web_services/"name"/class  ---->  vasDir/rest/class
		result = self.Tools.fileManipulator.RecursiveOverwriteCopy(os.path.join(self.Tools.params['ressourcesPath'], "vas", "web_services", self.name, "class"), os.path.join(self.Tools.params['vasDirectory'], "rest", "class"))
		if result[0] != 0:
			return result
		# copy ressources/vas/web_services/"name"/conf  ---->  vasDir/rest/conf/"name"
		result = self.Tools.fileManipulator.RecursiveOverwriteCopy(os.path.join(self.Tools.params['ressourcesPath'], "vas", "web_services", self.name, "conf"), os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", self.name))
		if result[0] != 0:
			return result

		# web_services configuration
		result = self.ConfigUp('install')
		if result[0] != 0:
			return result

		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", self.name, "version.inc"), "UNSTABLE", "STABLE")
		if result[0] != 0:
			return result
		return [0, ""]

	def ConfigUp(self, mode):
		if mode == 'update':
			self.Tools.logger.info(self.Tools.trad["WebService_6"])
			result = self.Tools.fileManipulator.RemoveAlias('vas', self.name)
			if result[0] != 0:
				return result
		result = self.Tools.fileManipulator.AddAlias('vas', self.name)
		if result[0] != 0:
			return result

		pathProperties = os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", self.name, "properties.inc")
		if os.path.isfile(pathProperties):
			result = self.Tools.fileManipulator.ReplaceInFile(pathProperties, "[ENV]", self.Tools.apache['environmentAlias'])
			if result[0] != 0:
				return result
		pathProperties = os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", self.name, "properties_server.inc")
		if os.path.isfile(pathProperties):
			result = self.Tools.fileManipulator.ReplaceInFile(pathProperties, "[ENV]", self.Tools.apache['environmentAlias'])
			if result[0] != 0:
				return result

		self.Tools.logger.debug(self.Tools.trad["WebService_7"])
		result = self.Tools.CheckApacheModule('vas', self.name)
		if result[0] != 0:
			return result

		return [0, ""]

	def GetVersion(self):
		# current version retrieval
		self.Tools.logger.debug(self.Tools.trad["WebService_8"])
		versionFile = open(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", self.name, "version.inc"), 'r', encoding="utf-8")
		versionFileData = versionFile.readlines()
		versionFile.close()
		currentVersion = '0'
		for line in versionFileData:
			if "VM_VERSION" in line:
				currentVersion = line.split('"')[-2]
				self.Tools.logger.debug(self.Tools.trad["WebService_9"].format(currentVersion))
				break
		return currentVersion

	def DisplayInfos(self):
		self.Tools.logger.debug(self.Tools.trad["WebService_10"].format(self.name))
		self.Tools.logger.debug(self.Tools.trad["WebService_11"].format(self.version))
		if self.Tools.params['vasDirectory'] is not None:
			self.Tools.logger.debug(self.Tools.trad["WebService_12"].format(self.Tools.params['vasDirectory']))
		self.Tools.logger.debug(self.Tools.trad["WebService_13"].format(self.Tools.apache['name']))
		self.Tools.logger.debug(self.Tools.trad["WebService_14"])
		for dependence in self.dependsOn:
			result = dependence.DisplayInfos()
			if result[0] != 0:
				return result
		return [0, ""]

	def Update(self):
		# checking if installed
		if not os.path.isdir(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", self.name)):
			return [1, self.Tools.trad["WebService_15"].format(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", self.name), self.name), inspect.stack()[0]]

		# checking ws status
		statusFile = open(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", self.name, "version.inc"), 'r', encoding="utf-8")
		statusFileData = statusFile.readlines()
		statusFile.close()
		status = None
		for line in statusFileData:
			if "VM_STATUS" in line:
				status = line.split('"')[-2]
				self.Tools.logger.debug(self.Tools.trad["WebService_16"].format(status))
			if "VM_VERSION" in line:
				currentVersion = line.split('"')[-2]
				self.Tools.logger.debug(self.Tools.trad["WebService_17"].format(currentVersion))
		if status is None:
			return [1, self.Tools.trad["WebService_18"], inspect.stack()[0]]
		if status != "STABLE":
			return [1, self.Tools.trad["WebService_19"], inspect.stack()[0]]
		if status == "STABLE":
			result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", self.name, "version.inc"), "STABLE", "UNSTABLE")
			if result[0] != 0:
				return result
		if currentVersion is None:
			return [1, self.Tools.trad["WebService_20"].format(self.name), inspect.stack()[0]]

		if currentVersion == "trunk" and self.version != "trunk":
			return [1, self.Tools.trad["WebService_21"], inspect.stack()[0]]
		if currentVersion != "" and currentVersion != "trunk" and self.version == "trunk":
			return [1, self.Tools.trad["WebService_22"], inspect.stack()[0]]

		# update version retrieval
		self.Tools.logger.debug(self.Tools.trad["WebService_23"])
		versionFile = open(os.path.join(self.Tools.params['ressourcesPath'], "vas", "web_services", self.name, "conf", "version.inc"), 'r', encoding="utf-8")
		versionFileData = versionFile.readlines()
		versionFile.close()
		updateVersion = None
		for line in versionFileData:
			if "VM_VERSION" in line:
				updateVersion = line.split('"')[-2]
		if updateVersion is None:
			return [1, self.Tools.trad["WebService_24"], inspect.stack()[0]]

		if updateVersion.replace(".", "") <= currentVersion.replace(".", ""):
			return [1, self.Tools.trad["WebService_25"], inspect.stack()[0]]

		try:
			# overwriting with last version of ws
			self.Tools.logger.info(self.Tools.trad["WebService_26"].format(self.name))

			# copy ressources/vas/web_services/"name"/ws  ---->  vasDir/rest/ws/"name"
			result = self.Tools.fileManipulator.RecursiveOverwriteCopy(os.path.join(self.Tools.params['ressourcesPath'], "vas", "web_services", self.name, "ws"), os.path.join(self.Tools.params['vasDirectory'], "rest", "ws", self.name))
			if result[0] != 0:
				return result
			# copy ressources/vas/web_services/"name"/ws_data  ---->  vasDir/ws_data
			result = self.Tools.fileManipulator.RecursiveOverwriteCopy(os.path.join(self.Tools.params['ressourcesPath'], "vas", "web_services", self.name, "ws_data"), os.path.join(self.Tools.params['vasDirectory'], "ws_data"))
			if result[0] != 0:
				return result
			# copy ressources/vas/web_services/"name"/public  ---->  vasDir/public/"name"
			result = self.Tools.fileManipulator.RecursiveOverwriteCopy(os.path.join(self.Tools.params['ressourcesPath'], "vas", "web_services", self.name, "public"), os.path.join(self.Tools.params['vasDirectory'], "public", self.name), None, True)
			if result[0] != 0:
				return result
			# copy ressources/vas/web_services/"name"/upload  ---->  vasDir/upload/"name"
			result = self.Tools.fileManipulator.RecursiveOverwriteCopy(os.path.join(self.Tools.params['ressourcesPath'], "vas", "web_services", self.name, "upload"), os.path.join(self.Tools.params['vasDirectory'], "upload", self.name))
			if result[0] != 0:
				return result
			# copy ressources/vas/web_services/"name"/class  ---->  vasDir/rest/class
			result = self.Tools.fileManipulator.RecursiveOverwriteCopy(os.path.join(self.Tools.params['ressourcesPath'], "vas", "web_services", self.name, "class"), os.path.join(self.Tools.params['vasDirectory'], "rest", "class"))
			if result[0] != 0:
				return result

			# Mise à jour du dossier conf
			self.Tools.logger.info(self.Tools.trad["WebService_27"])
			self.Tools.UpdateConfFolder(self.name)

			# web_services configuration
			result = self.ConfigUp('update')
			if result[0] != 0:
				return result

			# updating version.inc
			result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", self.name, "version.inc"), "UNSTABLE", "STABLE")
			if result[0] != 0:
				return result

		except BaseException as err:
			return [1, str(err), inspect.stack()[0]]
		return [0, ""]

	def Remove(self):
		depenceList = self.dependsOn
		for dependence in depenceList:
			if dependence.nature.startswith('extern'):
				result = dependence.CheckExtern(self.Tools.info['action'])
				if result[0] != 0:
					return result

		self.Tools.logger.info(self.Tools.trad["WebService_29"].format(self.name + self.Tools.apache['environmentAlias']))
		result = self.Tools.fileManipulator.RemoveAlias('vas', self.name)
		if result[0] != 0:
			return result
		return[0, ""]
