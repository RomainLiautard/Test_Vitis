# coding: utf-8
import inspect
import pg8000


class PostgresTools(object):

    def __init__(self):
        self.postgres = {}
        self.postgres['dbHost'] = self.args['dbHost']
        self.postgres['dbName'] = self.args['dbName']
        self.postgres['dbPort'] = self.args['dbPort']
        self.postgres['dbPassword'] = self.args['dbPassword']
        self.postgres['dbUsername'] = self.args['dbUsername']

    def GetPostgresVersion(self, host, port, username, password):
        connect = pg8000.connect(user=username, host=host, port=port, database="postgres", password=password)
        cursor = connect.cursor()
        cursor.execute("SELECT version()")
        queryReturn = cursor.fetchone()[0]
        version = queryReturn.split(",")[0].split()[1].split(".")
        return [0, version]

    def __ConnectToDatabase(self, database=None):
        if database is None:
            database = self.postgres['dbName']
        try:
            self.logger.debug(self.trad["PostgresTools_1"].format(self.postgres['dbHost'] + ":" + self.postgres['dbPort'] + ":" + database, self.postgres['dbUsername'] + " : " + self.postgres['dbPassword']))
            self.dbConn = pg8000.connect(user=self.postgres['dbUsername'], host=self.postgres['dbHost'], port=int(self.postgres['dbPort']), database=database, password=self.postgres['dbPassword'])
            self.logger.debug(self.trad["PostgresTools_2"])
            self.dbCursor = self.dbConn.cursor()
        except Exception as err:
            return [1, self.trad["PostgresTools_3"].format(str(err)), inspect.stack()[0]]
        return [0, ""]

    def __CloseDatabase(self):
        self.logger.debug(self.trad["PostgresTools_4"])
        self.dbCursor.close()
        return [0, ""]

    def GetQuery(self, request, database=None):
        result = self.__ConnectToDatabase(database)
        if result[0] != 0:
            return result
        error = ''
        try:
            self.dbCursor.execute(request)
            response = self.dbCursor.fetchone()
            if response is None:
                response = None
            else:
                response = response[0]
        except Exception as err:
            error = str(err)
        finally:
            result = self.__CloseDatabase()
            if error != '':
                return [1, self.trad["PostgresTools_5"].format(error), inspect.stack()[0]]
            if result[0] != 0:
                return result
        return [0, response]

    def CheckPostgresUser(self):
        # On vérifie si l'utilisateur indiqué est superuser
        self.logger.info("Checking Postgres User")
        bUserSuper = False
        result = self.GetQuery("select rolsuper from pg_roles where rolname = '" + self.postgres['dbUsername'] + "'", "postgres")
        if result[0] == 0:
            bUserSuper = result[1]
        else:
            return result
        
        # Il faut être superutilateur ou u_vitis pour faire l'install
        if not (bUserSuper or self.postgres['dbUsername'] == 'u_vitis'):
            return [1, 'dblogin parameter must be a superuser or u_vitis']

        # On regarde les droits de u_vitis
        bUserExist = True
        result = self.GetQuery("SELECT CASE WHEN rolcreaterole = false or rolcreatedb = false THEN false ELSE true END from pg_roles where rolname = 'u_vitis'", "postgres")
        if result[0] == 0:
            if self.postgres['dbUsername'] == 'u_vitis':
                if not result[1]:
                    return [1, 'u_vitis must have the rights to create databases and roles']
            elif result[1] is None:
                self.logger.debug(self.trad["Schema_20"])
                result = self.ExecuteSql("CREATE ROLE u_vitis LOGIN NOSUPERUSER INHERIT NOCREATEDB NOCREATEROLE NOREPLICATION", "postgres", True)
                if result[0] != 0:
                    return result
        else:
            return result
        return [0, '']
            
    def ExecuteSql(self, requestList, database=None, autoCommit=False):
        result = self.__ConnectToDatabase(database)
        if result[0] != 0:
            return result
        error = ''
        request = ''
        try:
            self.dbConn.autocommit = autoCommit
            if type(requestList).__name__ != 'list':
                tmp = requestList
                requestList = []
                requestList.append(tmp)
            for request in requestList:
                self.dbCursor.execute(request)

            if not autoCommit:
                self.dbConn.commit()
        except Exception as err:
            self.logger.error(request)
            error = str(err)
        finally:
            result = self.__CloseDatabase()
            if error != '':
                return [1, self.trad["PostgresTools_6"].format(error), inspect.stack()[0]]
            if result[0] != 0:
                return result
        return [0, ""]

    def CheckUser(self, user):
        self.logger.debug(self.trad["PostgresTools_7"])
        bUserExist = ""
        result = self.GetQuery("SELECT EXISTS(SELECT 1 FROM pg_catalog.pg_user WHERE lower(usename) = '" + user + "')", "postgres")
        if result[0] == 0:
            bUserExist = result[1]
        else:
            return result
        self.logger.debug(bUserExist)

        return [0, bUserExist]

    def GetVersionSchema(self, schema):
        # checking database existence, configure it if exist, else create one
        self.logger.debug(self.trad["PostgresTools_8"].format(self.postgres['dbName']))
        result = self.DatabaseExist()
        if result[0] == 0:
            databaseExist = result[1]
        else:
            return result

        sVersion = ''
        if databaseExist:
            # checking attributes
            self.logger.info(self.trad["PostgresTools_9"].format(schema))
            result = self.GetQuery("SELECT EXISTS(SELECT 1 FROM pg_namespace WHERE nspname = '" + schema + "')")
            bSchemaExist = False
            if result[0] == 0:
                bSchemaExist = result[1]
            else:
                return result

            if bSchemaExist:
                result = self.GetQuery("SELECT version FROM " + schema + ".version where active = true")
                if result[0] == 0:
                    sVersion = result[1]
                else:
                    return [1, self.trad["PostgresTools_10"].format(schema, result[1]), inspect.stack()[0]]
                self.logger.debug(self.trad["PostgresTools_11"].format(schema, sVersion))

        return [0, sVersion]

    def DatabaseExist(self):
        self.logger.debug(self.trad["PostgresTools_12"])
        result = self.GetQuery("SELECT EXISTS(SELECT 1 FROM pg_database WHERE datname = '" + self.postgres['dbName'] + "')", "postgres")
        if result[0] == 0:
            existingDatabase = result[1]
        else:
            return result
        return [0, existingDatabase]
