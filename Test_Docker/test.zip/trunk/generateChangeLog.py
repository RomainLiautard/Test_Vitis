# coding: utf-8
import os
import re
import pysvn
clientSvn = pysvn.Client()

rootSvn = "svn://vm02.veremes.net/produit_vitis"
rootSvnLocal = r"D:\svn\produit_vitis"
name = "md vmap|core|vas|ws vmap|ws vm4ms|md vm4ms|ws cadastre|ws cadastreV2"

# md  => modules
# core
# vas
# ws => web_services

aEquivalentName = {}
aEquivalentName['md'] = 'modules'
aEquivalentName['ws'] = 'web_services'

aName = name.split("|")
sNameObject = ""
for sName in aName:
	if sName in ("core", "vas"):
		sPath = sName
		sNameObject = sName
	else:
		tmp = sName.split(" ")
		sNameObject = tmp[1]
		sPath = aEquivalentName[tmp[0]] + '/' + tmp[1]

	print("Generating changelog => " + sPath)
	after = False
	lBefMessage = []
	lAfterMessage = []
	revisionFrom = 0
	if os.path.isfile(rootSvnLocal + '/' + sPath + "/trunk/CHANGE_LOG.txt"):
		result = clientSvn.update(rootSvnLocal + '/' + sPath + "/trunk/CHANGE_LOG.txt")
		changes = clientSvn.status(rootSvnLocal + '/' + sPath + "/trunk/CHANGE_LOG.txt")
		for f in changes:
			if f.text_status == pysvn.wc_status_kind.conflicted:
				print("Le fichier suivant est en conflit : " + rootSvnLocal + '/' + sPath + "/trunk/CHANGE_LOG.txt")
				raise SystemExit
		with open(rootSvnLocal + '/' + sPath + "/trunk/CHANGE_LOG.txt", encoding="utf-8") as file:
			for line in file:
				if not after:
					m = re.match(r'b([0-9]*)', line.lstrip('|'))
					if m:
						revisionFrom = int(m.group(1)) + 1
						after = True
				if after:
					lAfterMessage.append(line)
				else:
					lBefMessage.append(line)

	if os.path.isfile(rootSvnLocal + '/' + sPath + "/trunk/CHANGE_LOG.txt"):
		file = open(rootSvnLocal + '/' + sPath + "/trunk/CHANGE_LOG.txt", "w", encoding="utf-8")
		for message in lBefMessage:
			file.write(message.strip('\n\r') + '\n')
	else:
		file = open(rootSvnLocal + '/' + sPath + "/trunk/CHANGE_LOG.txt", "w", encoding="utf-8")

	if clientSvn.info(rootSvnLocal + '/' + sPath + "/trunk").data['revision'].number > revisionFrom:
		log_messages = clientSvn.log(rootSvn + '/' + sPath + "/trunk", revision_end=pysvn.Revision(pysvn.opt_revision_kind.number, revisionFrom))
		for log in log_messages:
			if log.data['message'] != "":
				aMessage = log.data['message'].split("\n")
				tracker = ""
				sMessage = ""
				for message in aMessage:
					if "id #" in message:
						continue
					if "fixes #" in message:
						continue
					if "EVOLUTION" in message:
						tracker = "EVOLUTION\t"
						if message.strip() == "EVOLUTION":
							continue
					if "BUG" in message:
						tracker = "BUG\t\t\t"
						if message.strip() == "BUG":
							continue
					if "IGNORE" in message:
						break
					sMessage = message + ' '
				if sMessage.strip() == "":
					continue
				if tracker == "":
					tracker = '\t\t\t\t'

				file.write('b' + str(log.data['revision'].number) + '|' + tracker + '|' + sNameObject + '|\t' + sMessage.strip() + '\n')

	if os.path.isfile(rootSvnLocal + '/' + sPath + "/trunk/CHANGE_LOG.txt"):
		for message in lAfterMessage:
			file.write(message.strip('\n\r') + '\n')
	file.close()
print("Finish")
