# coding: utf-8
import os
import shutil


class TraceBack(object):
	"""
	Class TraceBack description:
		Define a application by his name, version, dependence, installation directory,
		url of main Vitis Application Server and apache service it going to use to be accessed
		Attributes:
			list

		operations:
			New()
			Edit()
			Delete()
			BackUpIt()s
	"""
	def __init__(self):
		self.list = []
		self.aliasLinuxList = []
		self.serviceList = []
		self.ldConf = False

	def New(self, pathToFile):
		# addind a creation in traceback
		self.list.append((pathToFile, ''))
		return [0, ""]

	def Edit(self, pathToFile):
		# adding a edition in traceback
		alreadyBaked = False
		for tup in self.list:
			if pathToFile in tup:
				alreadyBaked = True
		if not alreadyBaked:
			self.BackUpIt(pathToFile)
			self.list.append((pathToFile, pathToFile + '.vai.bak'))
		return [0, ""]

	def Delete(self, pathToFile):
		# addind a removal in traceback
		self.BackUpIt(pathToFile)
		self.list.append(('', pathToFile + '.vai.bak'))
		return [0, ""]

	def BackUpIt(self, fileToBack):
		# copying file or directory with ".vai.bak"
		if os.path.isdir(fileToBack):
			if os.path.isdir(fileToBack + ".vai.bak"):
				shutil.rmtree(fileToBack + ".vai.bak")
			shutil.copytree(fileToBack, fileToBack + ".vai.bak")
		else:
			if os.path.isfile(fileToBack + ".vai.bak"):
				os.remove(fileToBack + ".vai.bak")
			shutil.copyfile(fileToBack, fileToBack + ".vai.bak")
		return [0, ""]

	def AddService(self, serviceName):
		self.serviceList.append(serviceName)
		return [0, ""]

	def AddAliasLinux(self, aliasFile):
		self.aliasLinuxList.append(aliasFile)
		return [0, ""]
