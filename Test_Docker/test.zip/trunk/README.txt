


			#############################################################
			#			 vtinst.exe and AIVitis.exe mini manual			#
			#				fast overview of how to use it				#
			#############################################################



vtinst.ex is used to setup vitis product which included:
	- vitis core webservice, his database and his schema
	- pre-prepared webservice for application, and related schemas
	- pre-prerared web-application based on vitis application

each of this product must be installed separatly
and each installation need to run this program, but with different parameters


AIVitis is a smart installation manager which will install one Application and all there dependencies (VAS, web service, database, ...)


#####################################################
# 			USER PART 								#
#####################################################


	#####################################
	#				VTINST				#
	#####################################

		Parameters VTinst.exe:
		---------------------
--action install/update/remove
--nature		app 		=> 		client + vasws
				client		=> 		client
				vasws		=>		vas + list(ws)
				vas			=> 		vas + schema
				ws			=>		ws + list(schema)	-s "nom du Ws"
				schema		=>		schema				-s "nom du schéma"

--service		nom du ws ou du schéma à faire l'action



		parameters are:
			-a/--action 						choose your action between: install/update/uninstall
			-n/--nature 						choose the type of the thing you want to action: app/ws/vas
			-s/--service 						identify the application or the webservice you want to action. note: not used for nature = vas
			-vashome 							installation directory for vas and webservice   DEVIENT directory
			-appdir 							installation directory for application          DEVIENT directory
			-db/--database 						specify database infos, "host,port,databaseName". note: not used for nature = app
			-dbuser/--databaseUsername			database connection information. note: not used for nature = app
			-dbpswd/--databasePassword			database connection information. note: not used for nature = app
			-as/--apacheservice 				specify apache service name, used to configure it for vitis. note: not used for nature = ws
			-vasurl								specify host of vas. note: used only for nature = app
			--appadmin					used to create the first vitis admin account which will be able to connect to vitis service.
			--appadminpswd				used to create the first vitis admin account which will be able to connect to vitis service. NOTE: if vitisadminlogin is an existing connection role in database, --vitisadminpassword is not needed and role's password will be used
			--verbose							used to intensify text displayed
			-env/--environment				used if more than one VAS are installed on the same server



		- Install VAS:
		  -----------
		vtinst.exe -a install -n vas -vashome E:\vitis\vas -conf E:\vitisInstall\installConf01.xml -p E:\vitisInstall\InstaPack01 -db localhost,5432,vitis -dbuser python -dbpswd python -as Apache2.4 --vitisadminlogin python -dep E:\vitisInstall\dependencies


		- Update VAS:
		  -----------
		vtinst.exe -a update -n vas -vashome E:\vitis\vas -conf E:\vitisInstall\installConf02.xml -p E:\vitisInstall\InstaPack02 -dbuser python -dbpswd python -as Apache2.4 -dep E:\vitisInstall\dependencies


		- Uninstall VAS:
		  -----------
		vtinst.exe -a uninstall -n vas -vashome E:\vitis\vas -conf E:\vitisInstall\installConf02.xml -p E:\vitisInstall\InstaPack02 -as Apache2.4 -dep E:\vitisInstall\dependencies




		- Install gtf WebService:
		  ----------------------
		vtinst.exe -a install -n ws -s gtf -vashome E:\vitis\vas -conf E:\vitisInstall\installConf01.xml -p E:\vitisInstall\InstaPack01 -db localhost,5432,vitis -dbuser python -dbpswd python -as Apache2.4 -dep E:\vitisInstall\dependencies


		- Update gtf WebService:
		  ----------------------
		vtinst.exe -a update -n ws -s gtf -vashome E:\vitis\vas -conf E:\vitisInstall\installConf02.xml -p E:\vitisInstall\InstaPack02 -db localhost,5432,vitis -dbuser python -dbpswd python -as Apache2.4 -dep E:\vitisInstall\dependencies




		- Install gtf Application:
		  -----------------------
		vtinst.exe -a install -n app -s gtf -appdir E:\vitis\gtf -conf E:\vitisInstall\installConf01.xml -p E:\vitisInstall\InstaPack01 -as Apache2.4 -vasurl https://gauby


		- Install gtf Application:
		  -----------------------
		vtinst.exe -a update -n app -s gtf -appdir E:\vitis\gtf -conf E:\vitisInstall\installConf02.xml -p E:\vitisInstall\InstaPack02 -as Apache2.4


		- Uninstall gtf Application:
		  -----------------------
		vtinst.exe -a uninstall -n app -s gtf -appdir E:\vitis\gtf -conf E:\vitisInstall\installConf02.xml -p E:\vitisInstall\InstaPack02 -as Apache2.4 -dep E:\vitisInstall\dependencies


	#####################################
	#				AIVITIS				#
	#####################################



		Parameters AIVitis.exe:
		 ---------------------

			-a/--action 								choose your action between: install/update/uninstall
			-app/--application 							select the application
			-dir/--directory 							select the directory of installation
			-p/--package 								specify the path to the package
			-as/--apacheservice 						specify apache service name, used to configure it for vitis.
			-env/--environment 						used if more than one VAS are installed on the same server
			-db/--databaseinfos 						specify database infos, "host,port,databaseName".
			-dblogin/--databaselogin 					database connection information.
			-dbpswd/--databasepassword 					database connection information.
			-appadmin/--applicationadministrator		specify first account which going to be admin
			-appadminpswd/--applicationadminpassword	specify first account password which going to be admin
			-vasurl 									specify host of vas.
			-only 										Used to install one part of the service
			--verbose 									used to intensify text displayed



		- Install GTF:
		  -----------
		AIVitis.exe -a install -app gtf -dir E:\vitis -p E:\vitisInstall\InstaPack02.zip -as Apache2.4 -env prod -db localhost,5432,vitis -dblogin python -dbpswd python -appadmin python -vasurl https://gauby



		- Update GTF:
		  -----------
		AIVitis.exe -a update -app gtf -dir E:\vitis -p E:\vitisInstall\InstaPack02.zip -as Apache2.4 -env prod -db localhost,5432,vitis -dblogin python -dbpswd python -appadmin python -vasurl https://gauby



		- Uninstall GTF:
		  -------------
		AIVitis.exe -a uninstall -app gtf -dir E:\vitis -p E:\vitisInstall\InstaPack02.zip -as Apache2.4 -env prod -db localhost,5432,vitis -dblogin python -dbpswd python -appadmin python -vasurl https://gauby




		you must not forget to erase database and all connection role related to vitis

			DROP DATABASE "yourDatabaseName";

			drop role u_vitis;
			drop role admin_framework;
			drop role framework_scheduler;
			drop role spatial_admin;
			drop role spatial_user;
			drop role vitis_admin;
			drop role vitis_user;
			drop role u_scheduler;

			drop role gtf_admin;
			drop role gtf_author;
			drop role gtf_scheduler;
			drop role gtf_user;
			drop role admin_gtf;




#####################################################
# 			DEV PART 								#
#####################################################


	#####################################
	# 			PIP INSTALL MODULE		#
	#####################################

		to use .py files, you must firstly get some module from the internet:
		pip install pyinstaller
		pip install pg8000
		pip install wmi
		pip install requests
		pip install xmldict	
		télécharger et installer pysvn prendre le pysvn correspondant à votre version de python (32 ou 64 bits) : http://pysvn.tigris.org/servlets/ProjectDocumentList?folderID=1768&expandFolder=1768&folderID=1762

	#####################################
	# 			VTINST Missings			#
	#####################################

		- langage selection
		- report for update, uninstall
		- report if error when doing things



	#####################################
	# 		Module Hidden Import		#
	#####################################


		vtinst use dynamic module import to import dependencies modules, that mean that pyinstaller is unable to find 
		these module by making a simple parsing of the code, you must help him.
		To do that, search in the vtinst directory the vtinst.spec 
		open it and you will find something like that:

		a = Analysis(['..\\Progs\\vtinst.py'],
		pathex=['C:\\Users\\a_bizien\\Documents\\Lab\\PyInstaller-3.0\\vtinst'],
			binaries=None,
			datas=None,
			hiddenimports=[],
			hookspath=None,
			runtime_hooks=None,
			excludes=None,
			win_no_prefer_redirects=None,
			win_private_assemblies=None,
			cipher=block_cipher)

		hiddenimport is what we want to complete
		syntax to add hidden import : 
			hiddenimport=['module1', 'module2', 'moduleDirectory', 'moduleDirectory.module3', 'moduleDirectory.module4']

		in our case, we will have something like that:
			hiddenimport=['dependencies', 'dependencies.dep_pycron', 'dependencies.dep_postgis', 'dependencies.dep_others']
			(note: don't forget that the extension ('.py') must not be informed)


	#####################################
	# 			Some Scripts			#
	#####################################


		----INSTALLATION VAS----

		chargement logger
		chargement file manipulator
		verification des prerequis globaux
			si lancé avec une session administrateur
			si apache configuré avec SSL
			que le package et le fichier de description de l'archive existe bien
		chargement des données de installConf

		lancement du processus choisi par l'utilisateur: installation
		verification de prerequis du vas
			verification prerequis externe
			verification du chemin d'installation

			verification prerequis du schema vitis
				verification si superuser dans la base de donnée
				verification si adminlogin existe en base de donnée
		lancement de l'installation du vas
			verification si deja installé
			verification si alias existe déja
			installation des redistribuables visual studio pour PHP
			copie des ressources dans le repertoire d'installation
			installation du schema vitis (cas particulier)
				verification que la base existe, sinon creation
				envoi du sql
				insertion en base de vitisAdmin, octroi les droit d'admin
			mise a jour du status

		configuration du vas
			recuperation de la version d'apache
			creation des alias (en fonction de la version)
			activation des modules apaches: deflate, headers, rewrite, ldap
			completion des properties du vas et du php
		reboot d'apache



		----INSTALLATION WS----

		chargement logger
		chargement file manipulator
		verification des prerequis globaux
			si lancé avec une session administrateur
			si apache configuré avec SSL
			que le package et le fichier de description de l'archive existe bien
		chargement des données de installConf

		lancement du processus choisi par l'utilisateur: installation
		verification de prerequis du ws
			verification prerequis externe + vas
			verification du chemin d'installation
			verification prerequis de chaque schema
				verification si superuser dans la base de donnée
		lancement de l'installation du ws
			verification si deja installé
			copie des ressources dans le vas
			installation du schema
				envoi du sql
			mise a jour du status
		reboot d'apache



		----INSTALLATION APP----

		chargement logger
		chargement file manipulator
		verification des prerequis globaux
			si lancé avec une session administrateur
			si apache configuré avec SSL
			que le package et le fichier de description de l'archive existe bien
		chargement des données de installConf

		lancement du processus choisi par l'utilisateur: installation
		verification de prerequis de l'app
			verification prerequis externe + ws
			verification du chemin d'installation

		lancement de l'installation de l'app
			verification si deja installé
			verification si alias existe déja
			copie des ressources dans le repertoire d'installation
			mise a jour du status

		configuration de l'app
			recuperation de la version d'apache
			creation des alias (en fonction de la version)
			completion des properties de l'app
		reboot d'apache



		----MAJ VAS----

		chargement logger
		chargement file manipulator
		verification des prerequis globaux
			si lancé avec une session administrateur
			si apache configuré avec SSL
			que le package et le fichier de description de l'archive existe bien
		chargement des données de installConf

		lancement du processus choisi par l'utilisateur: maj
		recuperation des données de connection à la base de donnée dans les properties
		verification de prerequis du vas
			verification prerequis externe
			verification du chemin d'installation
			verification prerequis du schema vitis
				verification si superuser dans la base de donnée
				verification si adminlogin existe en base de donnée
			arret d'apache
			lancement de la mise a jour : vas
				verification si deja installé
				verification status + UNSTABLE
				comparaison des numero de version
				backup du repertoire
				Ectrasement du repertoire vec exception des confs
				completion php.ini
				ajout de properties selon fichier xml
				modification du htaccess
				mise a jour du schema
				mise a jour du numero de version dans version.inc
				mise a jour du status
			demarrage d'apache



		----MAJ WS----

		chargement logger
		chargement file manipulator
		verification des prerequis globaux
			si lancé avec une session administrateur
			si apache configuré avec SSL
			que le package et le fichier de description de l'archive existe bien
		chargement des données de installConf

		lancement du processus choisi par l'utilisateur: maj
		recuperation des données de connection à la base de donnée dans les properties
		verification de prerequis du ws
			verification prerequis externe + vas
			verification du chemin d'installation
			verification prerequis de chaque schema
				verification si superuser dans la base de donnée
			arret d'apache
			lancement de la mise a jour : ws
				verification deja installé
				verification status
				comparaison de version
				Backup du repertoire
				Ectrasement du repertoire vec exception des confs
				ajout de properties selon fichier xml
				mise a jour du schema
				mise a jour du numero de version dans version.inc
				mise a jour du status
			demarrage d'apache



		----MAJ APP----

		chargement logger
		chargement file manipulator
		verification des prerequis globaux
			si lancé avec une session administrateur
			si apache configuré avec SSL
			que le package et le fichier de description de l'archive existe bien
		chargement des données de installConf

		lancement du processus choisi par l'utilisateur: maj
		verification de prerequis de l'app
			verification prerequis externe + ws
			verification du chemin d'installation
			arret d'apache
			lancement de la mise a jour : app
				verification deja installé
				verification status
				comparaison de version
				Backup du repertoire
				Ectrasement du repertoire vec exception des confs
				ajout de properties selon fichier xml
				mise a jour du numero de version dans version.inc
				mise a jour du status
			demarrage d'apache

