# --------------------------
# Paramètres
# --------------------------
# La nature de l'installation
# app => Application entière
# client => Uniquement la partie cliente
# vas => L'API rest
# ws => Un web service (exemple : vmap, gtf, etc...)
# schema => Un schéma
nature=app

# Répertoire d'installation
# Dans le cas suivant l'installeur créera le répertoire vmap s'il n'existe pas.
# Le répertoire vmap doit être vide afin d'installer l'application sinon l'installation échouera
dir=/var/www/[appName]

# Compte SUPERUSER sur le SGBD
dblogin=postgres
# Mot de passe du compte SUPERUSER
dbpswd=

# Nom du service apache
apacheService=apache2

# Port SSL d'Apache
apachePort=443

# SRID
[SRID]

# --------------------------
# Installation
# --------------------------
./[exeName] -a update -n $nature -as $apacheService -asport $apachePort -dir $dir -dblogin $dblogin -dbpswd $dbpswd [sridCommand]