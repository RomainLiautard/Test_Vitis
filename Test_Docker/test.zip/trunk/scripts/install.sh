# --------------------------
# Paramètres
# --------------------------
# La nature de l'installation
# app => Application entière
# client => Uniquement la partie cliente
# vas => L'API rest
# ws => Un web service (exemple : vmap, gtf, etc...)
# schema => Un schéma
nature=app

# Répertoire d'installation
# Dans le cas suivant l'installeur créera le répertoire vmap s'il n'existe pas.
# Le répertoire vmap doit être vide afin d'installer l'application sinon l'installation échouera
dir=/var/www/[appName]

# Paramètre pour la connexion au SGBD
# Si la bdd n'existe pas, elle sera créée
serveur=localhost
port=5432
# si la base de données existe l'installeur installera les schéma dans cette base sinon il créera la base
bdd=vitis

# Compte SUPERUSER sur le SGBD
dblogin=postgres
# Mot de passe du compte SUPERUSER
dbpswd=

# Nom du service apache
apacheService=apache2

# Port SSL d'Apache
apachePort=443

# Compte Administrateur de l'application
appAdmin=
# Son mot de passe
appPswd=

[SRID]

# --------------------------
# Installation
# --------------------------
./[exeName] -a install -n $nature -as $apacheService -asport $apachePort -dir $dir -db $serveur,$port,$bdd -dblogin $dblogin -dbpswd $dbpswd -appadmin $appAdmin -appadminpswd $appPswd [sridCommand]