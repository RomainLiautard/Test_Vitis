# coding: utf-8
import inspect
import os
import platform
import requests


class Installer(object):
	"""
	Class Installer description:
		Main class of the application, this class define what to do using arguments
		and know which component it is able to install/update
		Attributes:
			launchParameters
			confFile
			webServiceDict
			application
			header
			vas

		operations:
			LoadConfigurationFile()
			Install()
			RequisitesChecking()
			DisplayInfos()
	"""

	def __init__(self, Tools, info):
		self.info = info
		self.Tools = Tools

	def Launch(self):
		try:
			result = self.RequisitesCheckingDependencies()
			if result[0] != 0:
				return result
		except (BaseException) as err:
			self.Tools.logger.error(self.Tools.trad["Installer_1"].format(str(err)))
			return [1, str(err), inspect.stack()[0]]

		action = {"install": self.Install, "update": self.Update}
		try:
			report = {}
			report['name'] = self.info['name']
			report['action'] = self.info['action']
			report['status'] = 'successful'
			result = action[self.info['action']]()
			if (self.info['nature'] not in self.Tools.reportDict.keys()) and self.info['nature'] != 'vas' and self.info['nature'] != 'app':
				self.Tools.reportDict[self.info['nature']] = []
			if result[0] != 0:
				report['status'] = 'aborted'
				report['errorMessage'] = result[1]
				if self.info['nature'] != 'vas' and self.info['nature'] != 'app':
					self.Tools.reportDict[self.info['nature']].append(report)
				else:
					self.Tools.reportDict[self.info['nature']] = report
				return result

			if self.info['nature'] != 'vas' and self.info['nature'] != 'app':
				self.Tools.reportDict[self.info['nature']].append(report)
			else:
				self.Tools.reportDict[self.info['nature']] = report
		except (BaseException) as err:
			return [1, str(err), inspect.stack()[0]]
		return [0, ""]

	def RequisitesCheckingDependencies(self):
		# requisites checking
		if self.info['nature'] == "vas":
			depenceList = self.Tools.vas.dependsOn
		elif self.info['nature'] == "web_services":
			try:
				depenceList = self.Tools.webServiceDict[self.info['name']].dependsOn
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_2"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]
		elif self.info['nature'] == "schema":
			try:
				depenceList = self.Tools.schemaDict[self.info['name']].dependsOn
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_3"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]
		elif self.info['nature'] == "app":
			try:
				depenceList = self.Tools.application.dependsOn
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_4"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]

		for dependence in depenceList:
			if not dependence.nature.startswith('extern') and dependence.nature + dependence.name not in self.Tools.objectCheckList:
				self.Tools.objectCheckList.append(dependence.nature + dependence.name)
				result = dependence.Check()
				if result[0] == 0:
					version = result[1]
				else:
					return result

				if version == "trunk" and dependence.version != "trunk":
					return [1, self.Tools.trad["Installer_5"], inspect.stack()[0]]
				if version != "" and version != "trunk" and dependence.version == "trunk":
					return [1, self.Tools.trad["Installer_6"], inspect.stack()[0]]

				if version == '' or ((version != 'trunk') and (int(version.replace('.', '')) < int(dependence.version.replace('.', '')))):
					if not self.Tools.params['installDep']:
						if version == '':
							self.Tools.logger.error(self.Tools.trad["Installer_7"].format(dependence.name + " " + dependence.nature))
						else:
							self.Tools.logger.error(self.Tools.trad["Installer_8"].format(dependence.name + " " + dependence.nature))
						return [1, self.Tools.trad["Installer_9"], inspect.stack()[0]]
					else:
						dependenceInfo = {}
						if version == '':
							dependenceInfo['action'] = 'install'
							self.Tools.logger.info(self.Tools.trad["Installer_10"].format(((dependence.name + " ") if dependence.name != '' else '') + dependence.nature))
						else:
							dependenceInfo['action'] = 'update'
							self.Tools.logger.info(self.Tools.trad["Installer_11"].format(((dependence.name + " ") if dependence.name != '' else '') + dependence.nature))
						dependenceInfo['name'] = dependence.name
						dependenceInfo['nature'] = dependence.nature
						dependenceInstall = Installer(self.Tools, dependenceInfo)
						result = dependenceInstall.Launch()
						if result[0] != 0:
							self.Tools.fileManipulator.RollBack()
							return result
						self.Tools.fileManipulator.CleanTraceBack()
				else:
					if dependence.nature == 'vas':
						# Récupération
						try:
							result = self.Tools.StartApacheService()
							if result[0] != 0:
								return result
							r = requests.get(self.Tools.apache['checkUrl'] + "/rest" + self.Tools.apache['environmentAlias'] + "/vitis/properties", verify=False)
							database = r.json()['database']
							vas_home = r.json()['vas_home']
							result = self.Tools.StopApacheService()
							if result[0] != 0:
								return result
						except Exception as ke:
							return [1, ke, inspect.stack()[0]]
						errorMessage = ""
						if database != self.Tools.postgres['dbName']:
							errorMessage = self.Tools.trad["Installer_12"]

						vas_homeNormalize = os.path.abspath(vas_home)
						vas_directoryNormalize = os.path.abspath(self.Tools.params['vasDirectory'])
						if platform.system() == 'Windows':
							vas_homeNormalize = vas_homeNormalize.lower()
							vas_directoryNormalize = vas_directoryNormalize.lower()
						if vas_homeNormalize != vas_directoryNormalize:
							if errorMessage != "":
								errorMessage += "\n"
							errorMessage += self.Tools.trad["Installer_13"]
						if errorMessage != "":
							return [1, errorMessage, inspect.stack()[0]]
					else:
						self.Tools.logger.info(self.Tools.trad["Installer_14"].format(((dependence.name + " ") if dependence.name != '' else '') + dependence.nature))
		return [0, ""]

	def Install(self):
		# requisites checking
		if self.info['nature'] == "vas":
			depenceList = self.Tools.vas.dependsOn
		elif self.info['nature'] == "web_services":
			try:
				depenceList = self.Tools.webServiceDict[self.info['name']].dependsOn
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_15"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]
		elif self.info['nature'] == "schema":
			try:
				depenceList = self.Tools.schemaDict[self.info['name']].dependsOn
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_16"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]
		elif self.info['nature'] == "app":
			try:
				depenceList = self.Tools.application.dependsOn
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_17"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]

		# Lancement des dépendances externes (avant install)
		for dependence in depenceList:
			if dependence.nature == 'extern-pre':
				result = dependence.CheckExtern(self.info['action'])
				if result[0] != 0:
					return result

		# searching for what to install and launching installation and configuration process
		if self.info['nature'] == "vas":
			result = self.Tools.vas.Install()
			if result[0] != 0:
				return result
		elif self.info['nature'] == "web_services":
			try:
				result = self.Tools.webServiceDict[self.info['name']].Install()
				if result[0] != 0:
					return result
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_18"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]
		elif self.info['nature'] == "app":
			try:
				result = self.Tools.application.Install()
				if result[0] != 0:
					return result
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_19"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]
		elif self.info['nature'] == "schema":
			try:
				result = self.Tools.schemaDict[self.info['name']].Install()
				if result[0] != 0:
					return result
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_20"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]

		# Lancement des dépendances externes (après install)
		for dependence in depenceList:
			if dependence.nature == 'extern-post':
				result = dependence.CheckExtern(self.info['action'])
				if result[0] != 0:
					return result
		# restarting apache process to for him to consider changes
		result = self.Tools.RestopApacheService()

		if result[0] != 0:
			return result

		self.Tools.logger.info(self.Tools.trad["Installer_21"])
		return [0, ""]

	def Update(self):
		# requisites checking
		if self.info['nature'] == "vas":
			depenceList = self.Tools.vas.dependsOn
		elif self.info['nature'] == "web_services":
			try:
				depenceList = self.Tools.webServiceDict[self.info['name']].dependsOn
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_15"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]
		elif self.info['nature'] == "schema":
			try:
				depenceList = self.Tools.schemaDict[self.info['name']].dependsOn
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_16"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]
		elif self.info['nature'] == "app":
			try:
				depenceList = self.Tools.application.dependsOn
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_17"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]

		# Lancement des dépendances externes (avant install)
		for dependence in depenceList:
			if dependence.nature == 'extern-pre':
				result = dependence.CheckExtern(self.info['action'])
				if result[0] != 0:
					return result

		# searching for what to update and updating installation
		if self.info['nature'] == "vas":
			result = self.Tools.vas.Update()
			if result[0] != 0:
				return result
		elif self.info['nature'] == "web_services":
			try:
				result = self.Tools.webServiceDict[self.info['name']].Update()
				if result[0] != 0:
					return result
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_22"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]
		elif self.info['nature'] == "app":
			try:
				result = self.Tools.application.Update()
				if result[0] != 0:
					return result
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_23"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]
		elif self.info['nature'] == "schema":
			try:
				result = self.Tools.schemaDict[self.info['name']].Update()
				if result[0] != 0:
					return result
			except KeyError as ke:
				self.Tools.logger.error(self.Tools.trad["Installer_24"].format(self.info['name']))
				return [1, ke, inspect.stack()[0]]

		# Lancement des dépendances externes (après install)
		for dependence in depenceList:
			if dependence.nature == 'extern-post':
				result = dependence.CheckExtern(self.info['action'])
				if result[0] != 0:
					return result

		# restarting apache process to for him to consider changes
		result = self.Tools.RestopApacheService()

		self.Tools.logger.info(self.Tools.trad["Installer_25"])
		return [0, ""]
