# coding: utf-8
import inspect
import os
import shutil
import platform
import json
import time
from TraceBack import TraceBack


class FileManip(object):
	"""
	Class FileManip description:
	"""
	def __init__(self, Tools):
		self.Tools = Tools
		self.traceBack = TraceBack()

	def AddLdEntry(self, path):
		f = open('/etc/ld.so.conf','r')
		lignes  = f.readlines()
		f.close()

		resultLines = []
		for ligne in lignes:
			resultLines.append(ligne)
			if ligne.strip("\t ").strip().strip('\n\r') == path:
				return [0, '']
		resultLines.append('\n' + path)
		result = self.traceBack.Edit('/etc/ld.so.conf')
		if result[0] != 0:
			return result

		# Ajout d'une entrée dans le fichier ld.so.conf
		self.Tools.logger.info("Ajout d'une entrée dans le fichier ld.so.conf")
		f = open('/etc/ld.so.conf','w')
		for ligne in resultLines:
			f.write(ligne)
		f.close()

		self.traceBack.ldConf = True
		result = self.Tools.RunCommand(['ldconfig'])
		if result[0] != 0:
			return result
		return [0, '']

	def RemoveLdentry(self, path):
		f = open('/etc/ld.so.conf','r')
		lignes  = f.readlines()
		f.close()
		findPath = False
		resultLines = []
		for ligne in lignes:
			if ligne.strip("\t ").strip().strip('\n\r') != path:
				resultLines.append(ligne)
			else:
				findPath = True

		if findPath:
			result = self.traceBack.Edit('/etc/ld.so.conf')
			if result[0] != 0:
				return result
			result = self.Tools.RunCommand(['ldconfig'])
			if result[0] != 0:
				return result
			self.traceBack.ldConf = True
		else:
			return [0, '']

		return [0, '']


	def CreateDir(self, path):
		if not os.path.isdir(path):
			os.mkdir(path)
			result = self.traceBack.New(path)
			if result[0] != 0:
				return result
		return [0, ""]

	def CopyFile(self, src, dst):
		if not os.path.isfile(dst):
			shutil.copy(src, dst)

			result = self.traceBack.New(dst)
			if result[0] != 0:
				return result
		return [0, ""]

	def RollBack(self):
		self.Tools.logger.info(self.Tools.trad["FileManip_1"])
		# Suppression des services
		for serviceName in self.traceBack.serviceList:
			if platform.system() == 'Windows':
				result = self.Tools.RunCommand(['net', 'stop', serviceName])
				if result[0] != 0:
					return result
			else:
				if os.path.isfile('/etc/init.d/' + serviceName):
					result = self.Tools.RunCommand(['/etc/init.d/' + serviceName, 'stop'])
					if result[0] != 0:
						return result

		# Suppression des alias Apache sur Linux
		for tup in self.traceBack.aliasLinuxList:
			result = self.Tools.RunCommand(["a2dissite", tup])
			if result[0] != 0:
				return result
		if self.traceBack.ldConf:
			result = self.Tools.RunCommand(["ldconfig"])
			if result[0] != 0:
				return result

		for tup in self.traceBack.list:
			if tup[0] == "":
				if os.path.isdir(tup[1].replace(".vai.bak", "")):
					shutil.rmtree(tup[1].replace(".vai.bak", ""))
				elif os.path.isfile(tup[1].replace(".vai.bak", "")):
					os.remove(tup[1].replace(".vai.bak", ""))
				if os.path.isfile(tup[1]) or os.path.isdir(tup[1]):
					os.rename(tup[1], tup[1].replace(".vai.bak", ""))
			elif tup[1] == "":
				if os.path.isdir(tup[0]):
					shutil.rmtree(tup[0])
				elif os.path.isfile(tup[0]):
					os.remove(tup[0])
			else:
				if os.path.isdir(tup[0]):
					if os.path.isdir(tup[1]):
						shutil.rmtree(tup[0])
						time.sleep(1)
						os.rename(tup[1], tup[0])
				elif os.path.isfile(tup[0]):
					if os.path.isfile(tup[1]):
						os.remove(tup[0])
						os.rename(tup[1], tup[1].replace(".vai.bak", ""))
		return [0, ""]

	def CleanTraceBack(self):
		self.Tools.logger.info(self.Tools.trad["FileManip_2"])
		for tup in self.traceBack.list:
			self.Tools.logger.debug(tup)
			if os.path.isdir(tup[1]):
				try:
					shutil.rmtree(tup[1])
				except Exception:
					self.Tools.logger.error(self.Tools.trad["FileManip_6"].format(tup[1]))
			elif os.path.isfile(tup[1]):
				try:
					os.remove(tup[1])
				except Exception:
					self.Tools.logger.error(self.Tools.trad["FileManip_8"].format(tup[1]))
		self.traceBack.list = []
		self.traceBack.aliasLinuxList = []
		self.traceBack.serviceList = []
		return [0, ""]

	def AddService(self, serviceName):
		self.traceBack.AddService(serviceName)
		if platform.system() == 'Windows':
			result = self.Tools.RunCommand(['net', 'start', serviceName])
			if result[0] != 0:
				return result
		else:
			result = self.Tools.RunCommand(['/etc/init.d/' + serviceName, 'start'])
			if result[0] != 0:
				return result
		return [0, '']

	def AddAlias(self, serviceNat, serviceName=None):
		nameConf = serviceName if serviceName is not None else serviceNat
		if platform.system() == 'Windows':
			confFolder = os.path.join(self.Tools.apache['dirPath'], 'conf')
		else:
			confFolder = os.path.join(self.Tools.apache['dirPath'], 'sites-available')

		if serviceNat == 'app':
			src = os.path.join(self.Tools.params['ressourcesPath'], 'app', 'complement', 'apache.conf')
			nameConf = 'vm_app_' + self.Tools.application.name + self.Tools.apache['environmentAlias']
		elif serviceNat == 'vas':
			src = os.path.join(self.Tools.params['ressourcesPath'], 'vas', 'complement', serviceName if serviceName is not None else serviceNat, 'apache.conf')
			if serviceName is None:
				nameConf = 'vm_vas' + self.Tools.apache['environmentAlias']
			else:
				nameConf = 'vm_ws_' + serviceName + self.Tools.apache['environmentAlias']
		else:
			src = os.path.join(self.Tools.params['ressourcesPath'], 'dependencies', 'complement', serviceName, 'apache.conf')
			if not os.path.isfile(src):
				src = os.path.join(self.Tools.params['ressourcesPath'], 'dependencies', 'complement', platform.system().lower(), serviceName, 'apache.conf')
			nameConf = 'vm_' + serviceName + self.Tools.apache['environmentAlias']

		dst = os.path.join(confFolder, nameConf + '.conf')

		if os.path.isfile(src):
			# checking aliases
			result = self.Tools.DoesAliasExist(src)
			if result[0] == 0:
				alias = result[1]
			else:
				return result
			if alias != '':
				return [1, self.Tools.trad["FileManip_9"].format(alias), inspect.stack()[0]]

			with open(src, 'r') as openedFile:
				file = openedFile.read()

			# replacing expression
			file = file.replace('[ENV]', self.Tools.apache['environmentAlias'])
			file = file.replace('[VASDIRECTORY]', self.Tools.params['vasDirectory'])
			file = file.replace('[APPDIRECTORY]', self.Tools.params['appDirectory'])
			file = file.replace('[APP]', self.Tools.application.name)
			if platform.system() != 'Windows':
				file = file.replace('PassEnv TEMP', '')

			# writing result

			if not os.path.isfile(dst):
				result = self.traceBack.New(dst)
				if result[0] != 0:
					return result

			with open(dst, 'w') as openedFile:
				openedFile.write(file)

			result = self.traceBack.Edit(self.Tools.apache['confPath'])
			if result[0] != 0:
				return result
			with open(self.Tools.apache['confPath'], 'r', encoding="utf-8") as httpdFile:
				lines = httpdFile.read()

			includeExist = False
			if platform.system() == 'Windows':
				for line in lines.split('\n'):
					if 'Include conf/' + nameConf + '.conf' == line.strip():
						includeExist = True
						break

				if not includeExist:
					findAliasModule = False
					resultLines = []
					for line in lines.split('\n'):
						if findAliasModule and line.strip() == '</IfModule>':
							resultLines.append('\tInclude conf/' + nameConf + '.conf\n')
							findAliasModule = False
						if line.strip() == '<IfModule alias_module>':
							findAliasModule = True
						resultLines.append(line + '\n')

					resultLines[-1] = str(resultLines[-1]).rstrip('\n')
					with open(self.Tools.apache['confPath'], 'w', encoding="utf-8") as httpdFile:
						for line in resultLines:
							httpdFile.write(line)
			else:
				result = self.Tools.RunCommand(["a2ensite", nameConf + ".conf"])
				if result[0] == 0:
					lines = result[1]
				else:
					return result
				result = self.traceBack.AddAliasLinux(nameConf + ".conf")
				if result[0] != 0:
					return result

		return [0, ""]

	def RemoveAlias(self, serviceNat, serviceName=None):
		if platform.system() == 'Windows':
			confFolder = os.path.join(self.Tools.apache['dirPath'], 'conf')
		else:
			confFolder = os.path.join(self.Tools.apache['dirPath'], 'sites-available')

		if serviceNat == 'app':
			propertiesFile = open(os.path.join(self.Tools.params['appDirectory'], "conf", "properties.json"), 'r', encoding="utf-8")
			propertiesFileStr = propertiesFile.read()
			propertiesFile.close()
			propertiesFileData = json.loads(propertiesFileStr)
			if propertiesFileData['environment'] != "":
				propertiesFileData['environment'] = '_' + propertiesFileData['environment']
			nameConf = 'vm_app_' + propertiesFileData['application'] + propertiesFileData['environment']
		elif serviceNat == 'vas':
			if serviceName is None:
				nameConf = 'vm_vas' + self.Tools.apache['environmentAlias']
			else:
				nameConf = 'vm_ws_' + serviceName + self.Tools.apache['environmentAlias']
		else:
			nameConf = 'vm_' + serviceName + self.Tools.apache['environmentAlias']

		fileConf = os.path.join(confFolder, nameConf + '.conf')

		if os.path.isfile(fileConf):
			if platform.system() == 'Windows':
				with open(self.Tools.apache['confPath'], 'r', encoding="utf-8") as httpdFile:
					lines = httpdFile.read()
				resultLines = []
				for line in lines.split('\n'):
					if 'Include conf/' + nameConf + '.conf' != line.strip():
						resultLines.append(line + '\n')

				resultLines[-1] = str(resultLines[-1]).rstrip('\n')

				with open(self.Tools.apache['confPath'], 'w', encoding="utf-8") as httpdFile:
					for line in resultLines:
						httpdFile.write(line)
			else:
				result = self.Tools.RunCommand(["a2dissite", nameConf + ".conf"])
				if result[0] == 0:
					lines = result[1]
				else:
					return result
			os.remove(fileConf)
		return [0, ""]

	def EnableApacheModule(self, module):
		if platform.system() == 'Windows':
			self.Tools.logger.debug(self.Tools.trad["FileManip_10"].format(module))
			result = self.traceBack.Edit(self.Tools.apache['confPath'])
			if result[0] != 0:
				return result
			openedFile = open(self.Tools.apache['confPath'], 'r', encoding="iso-8859-1")
			dataFromFile = openedFile.read()
			openedFile.close()

			newDataForFile = ""
			for line in dataFromFile.split("\n"):
				newLine = ""
				if "#LoadModule " + module + "_module" in line:
					newLine = line.replace("#", "")
				else:
					newLine = line
				newDataForFile += newLine + "\n"

			openedFile = open(self.Tools.apache['confPath'], 'w', encoding="iso-8859-1")
			openedFile.write(newDataForFile)
			openedFile.close()
		else:
			result = self.Tools.RunCommand(["a2enmod", module])
			if result[0] != 0:
				return result
		return [0, ""]

	def ReplaceInFile(self, pathToFile, searchExp, replaceExp):
		# reading file
		result = self.traceBack.Edit(pathToFile)
		if result[0] != 0:
			return result
		with open(pathToFile, 'r', encoding="utf-8") as openedFile:
			dataFromFile = openedFile.read()

		# replacing expression
		dataFromFile = dataFromFile.replace(searchExp, replaceExp)
		# writing result
		with open(pathToFile, 'w', encoding="utf-8") as openedFile:
			openedFile.write(dataFromFile)

		return [0, ""]

	def RecursiveDelete(self, path):
		result = self.traceBack.Delete(path)
		if result[0] != 0:
			return result
		if os.path.isdir(path):
			shutil.rmtree(path)
		elif os .path.isfile(path):
			os.remove(path)
		return [0, ""]

	def ReplaceDirectory(self, src, dest):
		try:
			self.traceBack.Edit(dest)
			shutil.rmtree(dest)
			shutil.copytree(src, dest)
		except Exception as err:
			return [1, str(err), inspect.stack()[0]]
		return [0, ""]

	def RecursiveOverwriteCopy(self, src, dest, ignoreList=None, bOnlyNew=False):
		if os.path.isdir(src):
			if not os.path.isdir(dest):
				result = self.traceBack.New(dest)
				if result[0] != 0:
					return result
				os.makedirs(dest)
			files = os.listdir(src)

			for f in files:
				fAbsPath = os.path.join(src, f)
				mustIgnoreF = False
				# check if f must be ignored
				if ignoreList is not None:
					for ignore in ignoreList:
						if ignore in fAbsPath:
							self.Tools.logger.debug(self.Tools.trad["FileManip_11"].format(fAbsPath))
							mustIgnoreF = True

				if not mustIgnoreF:
					result = self.RecursiveOverwriteCopy(os.path.join(src, f), os.path.join(dest, f), ignoreList)
					if result[0] != 0:
						return result
		elif os.path.isfile(src):
			if os.path.isfile(dest):
				if not bOnlyNew:
					self.traceBack.Edit(dest)
					shutil.copyfile(src, dest)
			else:
				self.traceBack.New(dest)
				shutil.copyfile(src, dest)
		return [0, ""]

	def AppendToPropertiesFile(self, propertiesFilePath, dataDict):
		# reading properties file
		result = self.traceBack.Edit(propertiesFilePath)
		if result[0] != 0:
			return result
		propertiesFile = open(propertiesFilePath, 'r', encoding="utf-8")
		propertiesData = propertiesFile.readlines()
		propertiesFile.close()

		# finding end of file
		EOFindex = 0
		for index, line in enumerate(propertiesData):
			if "$properties" in line:
				EOFindex = index

		# adding properties to the end of file
		data = ''
		for properties in dataDict:
			data += properties[0] + ' = ' + properties[1] + ';\n'
		propertiesData.insert(EOFindex + 1, data)

		propertiesFile = open(propertiesFilePath, 'w', encoding="utf-8")
		propertiesFile.writelines(propertiesData)
		propertiesFile.close()
		return [0, ""]
