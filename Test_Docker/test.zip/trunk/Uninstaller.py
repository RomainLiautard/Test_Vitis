# coding: utf-8
import os


class Uninstaller(object):
	"""
	Class Uninstaller description:
		Main class of the application, this class define what to do using arguments
		and know which component it is able to install/update
		Attributes:
			launchParameters
			confFile
			webServiceList
			application
			header
			vas

		operations:
			LoadConfigurationFile()
			Install()
			RequisitesChecking()
			DisplayInfos()
	"""
	def __init__(self, Tools):
		self.Tools = Tools

	def Launch(self):
		# Uninstalling Application
		if self.Tools.info['nature'] == 'app':
			result = self.Remove('client')
			if result[0] != 0:
				self.Tools.fileManipulator.RollBack()
				return result
			self.Tools.fileManipulator.CleanTraceBack()

		# Uninstalling Webservices
		if self.Tools.info['nature'] in ('vas', 'app') and self.Tools.params['installDep']:
			for web_service in os.listdir(os.path.join(self.Tools.params['vasDirectory'], 'rest', 'ws')):
				if web_service in self.Tools.webServiceDict:
					result = self.Remove(web_service)
					if result[0] != 0:
						self.Tools.fileManipulator.RollBack()
						return result
					self.Tools.fileManipulator.CleanTraceBack()

			# Uninstalling Vas
			result = self.Remove('vas')
			if result[0] != 0:
				self.Tools.fileManipulator.RollBack()
				return result
			self.Tools.fileManipulator.CleanTraceBack()

		return [0, ""]

	def Remove(self, sObject):
		report = {}
		report['name'] = sObject
		report['action'] = 'uninstall'
		report['status'] = 'successful'

		if sObject == 'client':
			result = self.Tools.application.Remove()
		elif sObject == 'vas':
			result = self.Tools.vas.Remove()
		else:
			result = self.Tools.webServiceDict[sObject].Remove()

		if sObject not in (self.Tools.reportDict.keys(), 'vas', 'app', 'client'):
			self.Tools.reportDict[sObject] = []

		if result[0] != 0:
			report['status'] = 'aborted'
			report['errorMessage'] = result[1]

		if sObject not in ('vas', 'app', 'client'):
			self.Tools.reportDict[sObject].append(report)
		else:
			self.Tools.reportDict[sObject] = report

		return result
