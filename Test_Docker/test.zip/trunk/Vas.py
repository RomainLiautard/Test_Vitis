# coding: utf-8
import os
import inspect


class Vas(object):
	"""
	Class Vas description:
		Define a application by his name, version, dependence, installation directory,
		url of main Vitis Application Server and apache service it going to use to be accessed
		Attributes:
			directory
			schemaUsed
			apacheName
			dependsOn
			params

		operations:
			Install()
			ConfigUp()
			DisplayInfos()
	"""
	def __init__(self, Tools, version, dependsOn):
		self.Tools = Tools
		self.dependsOn = dependsOn
		self.version = version

	def Install(self):
		# checking if not already installed
		if os.path.isdir(self.Tools.params['vasDirectory']):
			currentVersion = self.getVersion().replace(".", "")
			version = self.version.replace(".", "")
			if currentVersion == '0':
				return [1, self.Tools.trad["Vas_1"].format(self.Tools.params['vasDirectory']), inspect.stack()[0]]
			elif version == currentVersion:
				if version == 'trunk':
					return [1, self.Tools.trad["Vas_32"].format(self.Tools.params['vasDirectory']), inspect.stack()[0]]
				else:
					return [1, self.Tools.trad["Vas_2"].format(self.Tools.params['vasDirectory']), inspect.stack()[0]]
			elif currentVersion < version:
				return [1, self.Tools.trad["Vas_3"].format(self.Tools.params['vasDirectory']), inspect.stack()[0]]
			else:
				return [1, self.Tools.trad["Vas_4"].format(self.Tools.params['vasDirectory']), inspect.stack()[0]]

		# ressources setup
		self.Tools.logger.info(self.Tools.trad["Vas_5"])
		result = self.Tools.fileManipulator.RecursiveOverwriteCopy(os.path.join(self.Tools.params['ressourcesPath'], "vas", "core"), self.Tools.params['vasDirectory'], [os.path.join(self.Tools.params['ressourcesPath'], "vas", "sql")])
		if result[0] != 0:
			return result
		# vas configuration
		result = self.ConfigUp('install')
		if result[0] != 0:
			return result
		# status update
		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", "version.inc"), "UNSTABLE", "STABLE")
		if result[0] != 0:
			return result
		return [0, ""]

	def getVersion(self):
		# current version retrieval
		self.Tools.logger.debug(self.Tools.trad["Vas_6"])
		versionFile = open(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", "version.inc"), 'r', encoding="utf-8")
		versionFileData = versionFile.readlines()
		versionFile.close()
		currentVersion = '0'
		for line in versionFileData:
			if "VM_VERSION" in line:
				currentVersion = line.split('"')[-2]
				self.Tools.logger.debug(self.Tools.trad["Vas_7"].format(currentVersion))
				break
		return currentVersion

	def ConfigUp(self, mode):
		self.Tools.logger.debug(self.Tools.trad["Vas_8"])
		result = self.Tools.CheckApacheModule('vas')
		if result[0] != 0:
			return result

		if mode == 'update':
			result = self.Tools.fileManipulator.RemoveAlias('vas')
			if result[0] != 0:
				return result
		result = self.Tools.fileManipulator.AddAlias('vas')
		if result[0] != 0:
			return result

		self.Tools.logger.info(self.Tools.trad["Vas_9"])
		self.Tools.logger.debug(self.Tools.trad["Vas_10"].format(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", "properties_server.inc")))
		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", "properties_server.inc"), "[VAS_HOME]", self.Tools.params['vasDirectory'].replace("\\", "/"))
		if result[0] != 0:
			return result
		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", "properties_server.inc"), "[DATABASE]", self.Tools.postgres['dbName'])
		if result[0] != 0:
			return result
		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", "properties_server.inc"), "[SERVER]", self.Tools.postgres['dbHost'])
		if result[0] != 0:
			return result
		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", "properties_server.inc"), "[PORT]", self.Tools.postgres['dbPort'])
		if result[0] != 0:
			return result
		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", "properties_server.inc"), "[APACHE]", self.Tools.apache['dirPath'].replace("\\", "/"))
		if result[0] != 0:
			return result
		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", ".htaccess"), "[ENV]", self.Tools.apache['environmentAlias'])
		if result[0] != 0:
			return result
		self.Tools.logger.debug(self.Tools.trad["Vas_11"].format(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", "properties.inc")))
		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", "properties.inc"), "[ENV]", self.Tools.apache['environmentAlias'])
		if result[0] != 0:
			return result
		result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", "properties_server.inc"), "[ENV]", self.Tools.apache['environmentAlias'])
		if result[0] != 0:
			return result
		return [0, ""]

	def Update(self):
		# checking if installed
		if not os.path.isdir(self.Tools.params['vasDirectory']):
			return [1, self.Tools.trad["Vas_12"].format(self.Tools.params['vasDirectory']), inspect.stack()[0]]
		# checking vas status
		statusFile = open(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", "version.inc"), 'r', encoding="utf-8")
		statusFileData = statusFile.readlines()
		statusFile.close()
		status = None
		for line in statusFileData:
			if "VM_STATUS" in line:
				status = line.split('"')[-2]
				self.Tools.logger.debug(self.Tools.trad["Vas_13"].format(status))
			if "VM_VERSION" in line:
				currentVersion = line.split('"')[-2]
				self.Tools.logger.debug(self.Tools.trad["Vas_14"].format(currentVersion))
		if status is None:
			return [1, self.Tools.trad["Vas_15"], inspect.stack()[0]]
		if status != "STABLE":
			return [1, self.Tools.trad["Vas_16"], inspect.stack()[0]]
		if status == "STABLE":
			result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", "version.inc"), "STABLE", "UNSTABLE")
			if result[0] != 0:
				return result

		if currentVersion is None:
			return [1, self.Tools.trad["Vas_17"], inspect.stack()[0]]
		if currentVersion == "trunk" and self.version != "trunk":
			return [1, self.Tools.trad["Vas_18"], inspect.stack()[0]]
		if currentVersion != "" and currentVersion != "trunk" and self.version == "trunk":
			return [1, self.Tools.trad["Vas_19"], inspect.stack()[0]]
		self.Tools.logger.info(self.Tools.trad["Vas_20"])

		# update version retrieval
		self.Tools.logger.debug(self.Tools.trad["Vas_21"])
		versionFile = open(os.path.join(self.Tools.params['ressourcesPath'], "vas", "core", "rest", "conf", "version.inc"), 'r', encoding="utf-8")
		versionFileData = versionFile.readlines()
		versionFile.close()
		updateVersion = None
		for line in versionFileData:
			if "VM_VERSION" in line:
				updateVersion = line.split('"')[-2]
				self.Tools.logger.debug(self.Tools.trad["Vas_22"].format(updateVersion))
				break
		if updateVersion is None:
			return [1, self.Tools.trad["Vas_23"], inspect.stack()[0]]

		if updateVersion.replace(".", "") <= currentVersion.replace(".", ""):
			return [1, self.Tools.trad["Vas_24"], inspect.stack()[0]]

		try:
			# overwriting with last version of vas, with exception of "conf"
			self.Tools.logger.info(self.Tools.trad["Vas_25"])
			result = self.Tools.fileManipulator.RecursiveOverwriteCopy(os.path.join(self.Tools.params['ressourcesPath'], "vas", "core"), self.Tools.params['vasDirectory'], [os.path.join(self.Tools.params['ressourcesPath'], "vas", "core", "rest", "conf"), os.path.join(self.Tools.params['ressourcesPath'], "vas", "core", "rest", ".htacces")])
			if result[0] != 0:
				return result

			# Mise à jour du dossier conf
			self.Tools.logger.info(self.Tools.trad["Vas_26"])
			self.Tools.UpdateConfFolder('vas')

			result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", ".htaccess"), "[ENV]", self.Tools.apache['environmentAlias'])
			if result[0] != 0:
				return result

			# vas configuration
			result = self.ConfigUp('update')
			if result[0] != 0:
				return result
			# updating version.inc
			result = self.Tools.fileManipulator.ReplaceInFile(os.path.join(self.Tools.params['vasDirectory'], "rest", "conf", "version.inc"), "UNSTABLE", "STABLE")
			if result[0] != 0:
				return result

		except BaseException as err:
			return [1, str(err), inspect.stack()[0]]
		return [0, ""]

	def DisplayInfos(self):
		self.Tools.logger.debug(self.Tools.trad["Vas_28"])
		if self.Tools.params['vasDirectory'] is not None:
			self.Tools.logger.debug(self.Tools.trad["Vas_29"].format(self.Tools.params['vasDirectory']))
		self.Tools.logger.debug(self.Tools.trad["Vas_30"].format(self.Tools.apache['name']))
		for dependence in self.dependsOn:
			result = dependence.DisplayInfos()
			if result[0] != 0:
				return result
		return [0, ""]

	def Remove(self):
		depenceList = self.dependsOn
		for dependence in depenceList:
			if dependence.nature.startswith('extern'):
				result = dependence.CheckExtern(self.Tools.info['action'])
				if result[0] != 0:
					return result

		self.Tools.logger.info(self.Tools.trad["Vas_31"])
		result = self.Tools.fileManipulator.RemoveAlias('vas')
		if result[0] != 0:
			return result

		result = self.Tools.fileManipulator.RecursiveDelete(self.Tools.params['vasDirectory'])
		if result[0] != 0:
			return result
		return [0, ""]
